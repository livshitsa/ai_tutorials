#!/bin/bash

# verify.sh - Verification script to ensure everything is working correctly

set -e

echo "🔍 Verifying Mastra Azure Monitor Local Package"
echo "============================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Verification functions
verify_directory_structure() {
    print_info "Checking directory structure..."
    
    local dirs=("lib/azure-monitor" "lib/azure-monitor/src" "src" "examples" "dist" "lib/azure-monitor/dist")
    for dir in "${dirs[@]}"; do
        if [ -d "$dir" ]; then
            print_success "Directory $dir exists"
        else
            print_error "Directory $dir missing"
            return 1
        fi
    done
}

verify_key_files() {
    print_info "Checking key files..."
    
    local files=(
        "lib/azure-monitor/package.json"
        "lib/azure-monitor/tsconfig.json"
        "lib/azure-monitor/src/index.ts"
        "lib/azure-monitor/src/azure-monitor-exporter.ts"
        "lib/azure-monitor/src/azure-monitor-provider.ts"
        "lib/azure-monitor/src/mastra-azure-monitor-integration.ts"
        "lib/azure-monitor/dist/index.js"
        "package.json"
        "tsconfig.json"
        "src/mastra.config.ts"
        "src/app.ts"
        "dist/app.js"
        "examples/basic-example.ts"
        "examples/complete-example.ts"
        ".env.example"
        "README.md"
        "QUICK_START.md"
    )
    
    for file in "${files[@]}"; do
        if [ -f "$file" ]; then
            print_success "File $file exists"
        else
            print_error "File $file missing"
            return 1
        fi
    done
}

verify_build_outputs() {
    print_info "Checking build outputs..."
    
    local build_files=(
        "lib/azure-monitor/dist/index.js"
        "lib/azure-monitor/dist/index.d.ts"
        "lib/azure-monitor/dist/azure-monitor-exporter.js"
        "lib/azure-monitor/dist/azure-monitor-provider.js"
        "lib/azure-monitor/dist/mastra-azure-monitor-integration.js"
        "dist/app.js"
        "dist/mastra.config.js"
        "dist/examples/basic-example.js"
        "dist/examples/complete-example.js"
    )
    
    for file in "${build_files[@]}"; do
        if [ -f "$file" ]; then
            print_success "Build output $file exists"
        else
            print_error "Build output $file missing"
            return 1
        fi
    done
}

verify_imports() {
    print_info "Testing imports..."
    
    # Test Azure Monitor package import
    node -e "
        try {
            const { createMastraWithAzureMonitor, setupGracefulShutdown, AzureMonitorHealthCheck } = require('./lib/azure-monitor/dist/index.js');
            console.log('✅ Azure Monitor package imports successfully');
            console.log('✅ Main exports available:', typeof createMastraWithAzureMonitor, typeof setupGracefulShutdown, typeof AzureMonitorHealthCheck);
        } catch (error) {
            console.error('❌ Azure Monitor package import failed:', error.message);
            process.exit(1);
        }
    "
    
    # Test main application import
    node -e "
        try {
            const mastra = require('./dist/mastra.config.js');
            console.log('✅ Main application imports successfully');
            console.log('✅ Mastra instance type:', typeof mastra.mastra);
        } catch (error) {
            console.error('❌ Main application import failed:', error.message);
            process.exit(1);
        }
    "
}

verify_environment() {
    print_info "Checking environment configuration..."
    
    if [ -f ".env" ]; then
        print_success ".env file exists"
        
        if grep -q "APPLICATIONINSIGHTS_CONNECTION_STRING" .env; then
            if grep -q "InstrumentationKey=12345678" .env; then
                print_warning ".env contains placeholder connection string"
                print_info "Remember to update with your real Azure Monitor connection string"
            else
                print_success ".env contains connection string configuration"
            fi
        else
            print_warning ".env missing APPLICATIONINSIGHTS_CONNECTION_STRING"
        fi
    else
        print_warning ".env file missing - copy from .env.example"
    fi
}

verify_functionality() {
    print_info "Testing basic functionality..."
    
    # Test basic Azure Monitor creation
    node -e "
        const { createMastraWithAzureMonitor } = require('./lib/azure-monitor/dist/index.js');
        
        try {
            const mastra = createMastraWithAzureMonitor({
                telemetry: {
                    serviceName: 'verification-test',
                    enabled: false, // Disable to avoid actual telemetry
                    export: {
                        type: 'azure-monitor',
                        connectionString: 'InstrumentationKey=test;IngestionEndpoint=https://test.com/',
                    },
                },
            });
            console.log('✅ Mastra with Azure Monitor created successfully');
            console.log('✅ Mastra instance type:', typeof mastra);
        } catch (error) {
            console.error('❌ Failed to create Mastra with Azure Monitor:', error.message);
            process.exit(1);
        }
    "
}

generate_report() {
    print_info "Generating verification report..."
    
    echo ""
    echo "📋 VERIFICATION REPORT"
    echo "====================="
    echo "Timestamp: $(date)"
    echo "Node.js Version: $(node --version)"
    echo "npm Version: $(npm --version)"
    echo "Platform: $(uname -s)"
    echo ""
    echo "Project Structure: ✅ Valid"
    echo "Build Outputs: ✅ Present"
    echo "Package Imports: ✅ Working"
    echo "Azure Monitor Integration: ✅ Functional"
    echo ""
    
    if [ -f ".env" ]; then
        if grep -q "InstrumentationKey=12345678" .env; then
            echo "Environment: ⚠️  Placeholder connection string"
            echo "Action Required: Update .env with real Azure Monitor connection string"
        else
            echo "Environment: ✅ Configured"
        fi
    else
        echo "Environment: ⚠️  No .env file"
        echo "Action Required: Copy .env.example to .env and configure"
    fi
    
    echo ""
    echo "🎯 READY TO USE"
    echo "==============="
    echo "✅ All verification checks passed"
    echo "✅ Package is ready for development and testing"
    echo ""
    echo "Next Steps:"
    echo "1. Update .env with your Azure Monitor connection string (if needed)"
    echo "2. Run 'npm run example:basic' to test"
    echo "3. Start developing with 'npm run dev'"
    echo ""
    echo "Quick Commands:"
    echo "  npm start              - Run main application"
    echo "  npm run example:basic  - Run basic example"
    echo "  npm run dev           - Development mode"
    echo "  npm run health        - Check system health"
}

# Main verification function
main() {
    echo "Starting verification process..."
    echo ""
    
    verify_directory_structure
    echo ""
    
    verify_key_files
    echo ""
    
    verify_build_outputs
    echo ""
    
    verify_imports
    echo ""
    
    verify_environment
    echo ""
    
    verify_functionality
    echo ""
    
    generate_report
}

# Run main function
main "$@"