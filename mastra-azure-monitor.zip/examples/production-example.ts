// production-example.ts - Production deployment example
import { 
  createMastraWithAzureMonitor, 
  setupGracefulShutdown,
  AzureMonitorHealthCheck 
} from '@local/azure-monitor';
import { Agent } from '@mastra/core/agent';
import { createTool } from '@mastra/core/tools';
import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { z } from 'zod';

// Production configuration based on environment
const productionConfig = {
  // Environment detection
  environment: process.env.NODE_ENV || 'development',
  isProduction: process.env.NODE_ENV === 'production',
  isStaging: process.env.NODE_ENV === 'staging',
  isDevelopment: process.env.NODE_ENV === 'development',
  
  // Service information
  serviceName: process.env.SERVICE_NAME || 'mastra-production-app',
  version: process.env.APP_VERSION || process.env.GITHUB_SHA?.substring(0, 8) || '1.0.0',
  region: process.env.AZURE_REGION || process.env.AWS_REGION || 'unknown',
  
  // Infrastructure
  clusterId: process.env.CLUSTER_ID || process.env.HOSTNAME || 'unknown',
  podName: process.env.POD_NAME || 'local',
  namespace: process.env.NAMESPACE || 'default',
  
  // Feature flags
  enableLiveMetrics: process.env.ENABLE_LIVE_METRICS === 'true',
  enableDebugLogging: process.env.ENABLE_DEBUG_LOGGING === 'true',
  
  // Performance settings
  samplingRate: parseFloat(process.env.SAMPLING_RATE || '0.1'), // Default 10% in production
  maxBatchSize: parseInt(process.env.MAX_BATCH_SIZE || '100'),
  batchIntervalMs: parseInt(process.env.BATCH_INTERVAL_MS || '5000'),
};

// Production-grade external API tool
const externalAPITool = createTool({
  id: 'call-external-api',
  description: 'Call external production API with retry logic',
  inputSchema: z.object({
    endpoint: z.string(),
    data: z.record(z.any()).optional(),
  }),
  execute: async ({ context }) => {
    const maxRetries = 3;
    let lastError: Error | null = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`External API call attempt ${attempt} to ${context.endpoint}`);
        
        // Simulate API call with realistic latency and error rates
        const latency = 50 + Math.random() * 200; // 50-250ms
        await new Promise(resolve => setTimeout(resolve, latency));
        
        // Simulate 5% error rate, but decrease with retries
        const errorRate = 0.05 / attempt;
        if (Math.random() < errorRate) {
          throw new Error(`API call failed on attempt ${attempt}`);
        }
        
        return {
          endpoint: context.endpoint,
          data: context.data,
          attempt,
          latency: Math.round(latency),
          timestamp: new Date().toISOString(),
          success: true,
        };
        
      } catch (error) {
        lastError = error as Error;
        console.warn(`API call attempt ${attempt} failed:`, error);
        
        if (attempt < maxRetries) {
          // Exponential backoff
          const backoffMs = Math.pow(2, attempt) * 100;
          await new Promise(resolve => setTimeout(resolve, backoffMs));
        }
      }
    }
    
    throw new Error(`API call failed after ${maxRetries} attempts: ${lastError?.message}`);
  },
});

// Production monitoring tool
const monitoringTool = createTool({
  id: 'system-metrics',
  description: 'Get system metrics for monitoring',
  inputSchema: z.object({
    includeDetails: z.boolean().optional().default(false),
  }),
  execute: async ({ context }) => {
    const memoryUsage = process.memoryUsage();
    const uptime = process.uptime();
    
    const metrics = {
      timestamp: new Date().toISOString(),
      uptime: Math.round(uptime),
      memory: {
        rss: Math.round(memoryUsage.rss / 1024 / 1024), // MB
        heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024), // MB
        heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024), // MB
        external: Math.round(memoryUsage.external / 1024 / 1024), // MB
      },
      cpu: {
        loadAverage: process.platform !== 'win32' ? require('os').loadavg() : [0, 0, 0],
        platform: process.platform,
        arch: process.arch,
      },
    };
    
    if (context.includeDetails) {
      return {
        ...metrics,
        environment: productionConfig,
        nodeVersion: process.version,
        pid: process.pid,
      };
    }
    
    return metrics;
  },
});

// Production agents with different models for redundancy
const primaryAgent = new Agent({
  name: 'primaryAgent',
  instructions: `You are the primary production assistant. Handle requests efficiently and professionally.
    Use external APIs when needed and provide system metrics when requested.`,
  model: openai('gpt-4'), // Primary model
  tools: [externalAPITool, monitoringTool],
});

const fallbackAgent = new Agent({
  name: 'fallbackAgent',
  instructions: `You are the fallback assistant. Provide reliable responses when the primary agent is unavailable.`,
  model: anthropic('claude-3-haiku-20240307'), // Faster, cheaper fallback
  tools: [monitoringTool],
});

// Production Mastra configuration with comprehensive settings
const mastra = createMastraWithAzureMonitor({
  agents: {
    primary: primaryAgent,
    fallback: fallbackAgent,
  },
  tools: {
    externalAPI: externalAPITool,
    systemMetrics: monitoringTool,
  },
  telemetry: {
    serviceName: productionConfig.serviceName,
    enabled: true,
    
    // Environment-specific sampling
    sampling: {
      type: productionConfig.isProduction ? 'ratio' : 'always_on',
      probability: productionConfig.isProduction ? productionConfig.samplingRate : 1.0,
    },
    
    export: {
      type: 'azure-monitor',
      connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
      
      // Performance settings based on environment
      maxBatchSize: productionConfig.maxBatchSize,
      maxBatchIntervalMs: productionConfig.batchIntervalMs,
      samplingPercentage: productionConfig.isProduction ? productionConfig.samplingRate * 100 : 100,
      
      // Production features
      enableLiveMetrics: productionConfig.enableLiveMetrics,
      enableAutoCollectExceptions: true,
      enableAutoCollectPerformance: true,
      enableAutoCollectDependencies: true,
      enableAutoCollectRequests: true,
      enableInternalDebugLogging: productionConfig.enableDebugLogging,
      enableInternalWarningLogging: true,
      
      // Application context
      environment: productionConfig.environment,
      version: productionConfig.version,
      cloudRole: productionConfig.serviceName,
      cloudRoleInstance: `${productionConfig.serviceName}-${productionConfig.podName}`,
      
      // Comprehensive tags for production monitoring
      customTags: {
        // Environment classification
        'env.type': productionConfig.environment,
        'env.production': productionConfig.isProduction.toString(),
        'env.staging': productionConfig.isStaging.toString(),
        
        // Service identification
        'service.name': productionConfig.serviceName,
        'service.version': productionConfig.version,
        'service.region': productionConfig.region,
        
        // Infrastructure details
        'infra.cluster': productionConfig.clusterId,
        'infra.pod': productionConfig.podName,
        'infra.namespace': productionConfig.namespace,
        'infra.node-version': process.version,
        'infra.platform': process.platform,
        
        // Deployment metadata
        'deploy.timestamp': process.env.DEPLOY_TIMESTAMP || new Date().toISOString(),
        'deploy.commit': process.env.GITHUB_SHA || 'unknown',
        'deploy.branch': process.env.GITHUB_REF_NAME || 'unknown',
        'deploy.pipeline': process.env.GITHUB_RUN_ID || 'unknown',
        
        // Business context
        'business.team': process.env.TEAM_NAME || 'platform',
        'business.cost-center': process.env.COST_CENTER || 'engineering',
        'business.product': process.env.PRODUCT_NAME || 'ai-platform',
        
        // Feature flags
        'feature.live-metrics': productionConfig.enableLiveMetrics.toString(),
        'feature.debug-logging': productionConfig.enableDebugLogging.toString(),
        'feature.sampling-rate': productionConfig.samplingRate.toString(),
      },
    },
  },
});
// Setup graceful shutdown with production-grade error handling
setupGracefulShutdown(mastra);

// Health monitoring
const healthMonitor = new AzureMonitorHealthCheck(mastra);

// Production request handlers with error handling and circuit breaker pattern
let circuitBreakerOpen = false;
let failureCount = 0;
const maxFailures = 5;
const circuitBreakerTimeout = 60000; // 1 minute

export async function handleProductionRequest(
  requestType: 'primary' | 'fallback',
  input: string,
  userId?: string
) {
  const startTime = Date.now();
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  console.log(`[${requestId}] Processing ${requestType} request for user ${userId || 'anonymous'}`);
  
  try {
    // Circuit breaker logic
    if (circuitBreakerOpen && requestType === 'primary') {
      console.warn(`[${requestId}] Circuit breaker open, using fallback agent`);
      requestType = 'fallback';
    }
    
    const agent = mastra.getAgent(requestType);
    if (!agent) {
      throw new Error(`Agent ${requestType} not found`);
    }
    
    // Execute the request
    const response = await agent.generate([
      {
        role: 'user',
        content: input,
      },
    ]);
    
    const duration = Date.now() - startTime;
    
    // Reset circuit breaker on success
    if (failureCount > 0) {
      failureCount = 0;
      if (circuitBreakerOpen) {
        circuitBreakerOpen = false;
        console.log(`[${requestId}] Circuit breaker reset`);
      }
    }
    
    console.log(`[${requestId}] Request completed successfully in ${duration}ms`);
    
    return {
      success: true,
      requestId,
      agentUsed: requestType,
      response: response.text,
      duration,
      userId,
      timestamp: new Date().toISOString(),
    };
    
  } catch (error) {
    const duration = Date.now() - startTime;
    failureCount++;
    
    console.error(`[${requestId}] Request failed after ${duration}ms:`, error);
    
    // Circuit breaker logic
    if (failureCount >= maxFailures && !circuitBreakerOpen) {
      circuitBreakerOpen = true;
      console.error(`[${requestId}] Circuit breaker opened after ${failureCount} failures`);
      
      // Auto-reset circuit breaker after timeout
      setTimeout(() => {
        circuitBreakerOpen = false;
        failureCount = 0;
        console.log('Circuit breaker auto-reset');
      }, circuitBreakerTimeout);
    }
    
    // Try fallback if primary failed and circuit breaker allows
    if (requestType === 'primary' && !circuitBreakerOpen) {
      console.log(`[${requestId}] Retrying with fallback agent`);
      return handleProductionRequest('fallback', input, userId);
    }
    
    return {
      success: false,
      requestId,
      agentUsed: requestType,
      error: error instanceof Error ? error.message : 'Unknown error',
      duration,
      userId,
      timestamp: new Date().toISOString(),
    };
  }
}

export async function getSystemHealth() {
  try {
    const healthCheck = await healthMonitor.checkHealth();
    const metrics = await monitoringTool.execute({ context: { includeDetails: true } });
    
    return {
      overall: healthCheck.healthy ? 'healthy' : 'unhealthy',
      azureMonitor: healthCheck,
      systemMetrics: metrics,
      circuitBreaker: {
        open: circuitBreakerOpen,
        failureCount,
        maxFailures,
      },
      configuration: {
        environment: productionConfig.environment,
        samplingRate: productionConfig.samplingRate,
        liveMetrics: productionConfig.enableLiveMetrics,
      },
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      overall: 'error',
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString(),
    };
  }
}

export async function simulateProductionLoad() {
  console.log('🏭 Simulating production load...');
  
  const requests = [
    'Process this customer inquiry about billing',
    'Generate a summary of our product features',
    'Help with technical support for API integration',
    'Create a response to a feature request',
    'Analyze this error report and suggest solutions',
    'Generate documentation for our new feature',
    'Process this feedback and categorize it',
    'Create a professional response to a complaint',
  ];
  
  const userIds = ['user1', 'user2', 'user3', 'user4', 'user5'];
  
  // Create a mix of concurrent requests
  const concurrentRequests = [];
  
  for (let i = 0; i < 20; i++) {
    const request = requests[Math.floor(Math.random() * requests.length)];
    const userId = userIds[Math.floor(Math.random() * userIds.length)];
    const agentType = Math.random() > 0.2 ? 'primary' : 'fallback'; // 80% primary, 20% fallback
    
    // Add some delay to spread out requests
    const delay = Math.random() * 2000; // 0-2 seconds
    
    concurrentRequests.push(
      new Promise(resolve => 
        setTimeout(() => 
          handleProductionRequest(agentType, request, userId).then(resolve),
          delay
        )
      )
    );
  }
  
  console.log('Executing 20 concurrent requests...');
  const results = await Promise.all(concurrentRequests);
  
  // Analyze results
  const successful = results.filter(r => r.success).length;
  const failed = results.filter(r => !r.success).length;
  const avgDuration = results.reduce((sum, r) => sum + r.duration, 0) / results.length;
  const primaryUsed = results.filter(r => r.agentUsed === 'primary').length;
  const fallbackUsed = results.filter(r => r.agentUsed === 'fallback').length;
  
  return {
    totalRequests: results.length,
    successful,
    failed,
    successRate: (successful / results.length) * 100,
    averageDuration: Math.round(avgDuration),
    agentUsage: {
      primary: primaryUsed,
      fallback: fallbackUsed,
    },
    circuitBreakerStatus: {
      open: circuitBreakerOpen,
      failureCount,
    },
  };
}

async function runProductionExample() {
  console.log('🏭 Running Production Deployment Example');
  console.log('This example demonstrates production-ready Azure Monitor integration');
  console.log('');
  console.log('Configuration:');
  console.log(`  Environment: ${productionConfig.environment}`);
  console.log(`  Service: ${productionConfig.serviceName}`);
  console.log(`  Version: ${productionConfig.version}`);
  console.log(`  Sampling Rate: ${productionConfig.samplingRate * 100}%`);
  console.log(`  Live Metrics: ${productionConfig.enableLiveMetrics}`);
  console.log('');

  try {
    // 1. Health check
    console.log('--- System Health Check ---');
    const health = await getSystemHealth();
    console.log('Health Status:', health.overall);
    console.log('Circuit Breaker:', health.circuitBreaker.open ? 'OPEN' : 'CLOSED');
    console.log('');

    // 2. Single request test
    console.log('--- Single Request Test ---');
    const singleResult = await handleProductionRequest(
      'primary',
      'Hello! This is a production test request.',
      'test-user'
    );
    console.log('Single Request:', singleResult.success ? '✅ Success' : '❌ Failed');
    console.log('Response time:', `${singleResult.duration}ms`);
    console.log('');

    // 3. Load simulation
    console.log('--- Production Load Simulation ---');
    const loadResults = await simulateProductionLoad();
    console.log('Load Test Results:');
    console.log(`  Total Requests: ${loadResults.totalRequests}`);
    console.log(`  Success Rate: ${loadResults.successRate.toFixed(1)}%`);
    console.log(`  Average Duration: ${loadResults.averageDuration}ms`);
    console.log(`  Primary Agent: ${loadResults.agentUsage.primary} requests`);
    console.log(`  Fallback Agent: ${loadResults.agentUsage.fallback} requests`);
    console.log(`  Circuit Breaker: ${loadResults.circuitBreakerStatus.open ? 'OPEN' : 'CLOSED'}`);
    console.log('');

    // 4. Final health check
    console.log('--- Final Health Check ---');
    const finalHealth = await getSystemHealth();
    console.log('Final Health Status:', finalHealth.overall);
    console.log('Memory Usage:', `${finalHealth.systemMetrics.memory.rss}MB RSS`);
    console.log('Uptime:', `${finalHealth.systemMetrics.uptime}s`);
    console.log('');

    console.log('✅ Production example completed successfully!');
    console.log('📊 All telemetry has been sent to Azure Monitor with production configuration');
    console.log('🔧 Check your Application Insights dashboard for:');
    console.log('   - Distributed traces with correlation IDs');
    console.log('   - Performance metrics and success rates');
    console.log('   - Custom properties and business context');
    console.log('   - Exception tracking and error analysis');
    console.log('   - Live metrics (if enabled)');
    
  } catch (error) {
    console.error('❌ Error in production example:', error);
    throw error;
  }
}

// Export for use in other files
export { mastra, productionConfig, runProductionExample };

// Run if this file is executed directly
if (require.main === module) {
  runProductionExample()
    .then(() => {
      console.log('Production example finished');
      setTimeout(() => process.exit(0), 3000);
    })
    .catch((error) => {
      console.error('Production example failed:', error);
      process.exit(1);
    });
}