// basic-example.ts - Simple usage example
import { createMastraWithAzureMonitor, setupGracefulShutdown } from '@local/azure-monitor';
import { Agent } from '@mastra/core/agent';
import { azure } from '@ai-sdk/azure';

// Create a simple agent
const simpleAgent = new Agent({
  name: 'simpleAgent',
  instructions: 'You are a helpful assistant that responds concisely.',
  model: azure('gpt-4.1-mini-poc'),
});

// Configure Mastra with Azure Monitor - minimal setup
const mastra = createMastraWithAzureMonitor({
  agents: {
    simple: simpleAgent,
  },
  telemetry: {
    serviceName: 'basic-example',
    enabled: true,
    export: {
      type: 'azure-monitor',
      connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING || 'placeholder',
    },
  },
});

// Setup graceful shutdown
setupGracefulShutdown(mastra);

async function runBasicExample() {
  console.log('🔵 Running Basic Example');
  console.log('This example shows minimal Azure Monitor integration');
  console.log('');

  try {
    const agent = mastra.getAgent('simple');
    
    console.log('Sending request to agent...');
    const response = await agent.generate([
      {
        role: 'user',
        content: 'Hello! Can you tell me what you are?',
      },
    ]);

    console.log('Agent Response:', response.text);
    console.log('');
    console.log('✅ Basic example completed successfully!');
    console.log('📊 This interaction was automatically traced to Azure Monitor');
    
  } catch (error) {
    console.error('❌ Error in basic example:', error);
    throw error;
  }
}

// Export for use in other files
export { mastra, runBasicExample };

// Run if this file is executed directly
if (require.main === module) {
  runBasicExample()
    .then(() => {
      console.log('Basic example finished');
      setTimeout(() => process.exit(0), 1000);
    })
    .catch((error) => {
      console.error('Basic example failed:', error);
      process.exit(1);
    });
}