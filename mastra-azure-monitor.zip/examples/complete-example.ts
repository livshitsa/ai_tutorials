// complete-example.ts - Full implementation example
import { createMastraWithAzureMonitor, setupGracefulShutdown } from '@local/azure-monitor';
import { Agent } from '@mastra/core/agent';
import { createTool } from '@mastra/core/tools';
import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { z } from 'zod';

// Environment configuration
const config = {
  connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
  environment: process.env.NODE_ENV || 'development',
  version: process.env.APP_VERSION || '1.0.0',
  serviceName: process.env.SERVICE_NAME || 'mastra-demo-app',
  region: process.env.AZURE_REGION || 'eastus',
  clusterId: process.env.CLUSTER_ID || 'local',
};

// Custom tools that will be automatically traced
const weatherTool = createTool({
  id: 'get-weather',
  description: 'Get current weather for a location',
  inputSchema: z.object({
    location: z.string().describe('The city and country'),
    units: z.enum(['celsius', 'fahrenheit']).default('celsius'),
  }),
  execute: async ({ context }) => {
    // This simulates an API call that will be automatically traced as a dependency
    console.log(`Fetching weather for ${context.location}`);
    
    // Simulate API latency
    await new Promise(resolve => setTimeout(resolve, 100 + Math.random() * 200));
    
    // Simulate potential errors (5% chance)
    if (Math.random() < 0.05) {
      throw new Error('Weather service temporarily unavailable');
    }
    
    const temperature = context.units === 'fahrenheit' 
      ? Math.round(15 + Math.random() * 60) // 15-75°F
      : Math.round(-10 + Math.random() * 35); // -10-25°C
    
    return {
      location: context.location,
      temperature,
      description: ['Sunny', 'Partly cloudy', 'Cloudy', 'Rainy'][Math.floor(Math.random() * 4)],
      humidity: Math.round(30 + Math.random() * 40), // 30-70%
      units: context.units,
    };
  },
});
const databaseTool = createTool({
  id: 'query-database',
  description: 'Query user preferences from database',
  inputSchema: z.object({
    userId: z.string(),
    query: z.string(),
  }),
  execute: async ({ context }) => {
    // Simulate database query - this will be traced as a dependency
    console.log(`Querying database for user ${context.userId}`);
    await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 100)); // Simulate latency
    
    return {
      userId: context.userId,
      preferences: {
        language: 'en',
        timezone: 'UTC',
        theme: Math.random() > 0.5 ? 'dark' : 'light',
        notifications: Math.random() > 0.3,
      },
      lastActive: new Date().toISOString(),
      queryExecuted: context.query,
    };
  },
});

// Define agents with different models
const weatherAgent = new Agent({
  name: 'weatherAgent',
  instructions: `You are a weather assistant. Use the weather tool to get current conditions 
    and provide helpful, conversational responses about the weather.`,
  model: openai('gpt-4'),
  tools: [weatherTool],
});

const analyticsAgent = new Agent({
  name: 'analyticsAgent', 
  instructions: `You are a data analytics assistant. Help users understand their data
    and provide insights. Use the database tool to fetch user information when needed.`,
  model: anthropic('claude-3-haiku-20240307'),
  tools: [databaseTool],
});

const generalAgent = new Agent({
  name: 'generalAgent',
  instructions: `You are a helpful general-purpose assistant. You can help with various
    tasks and questions. Be conversational and helpful.`,
  model: openai('gpt-3.5-turbo'),
});
// Create Mastra instance with Azure Monitor integration
const mastra = createMastraWithAzureMonitor({
  // Mastra configuration
  agents: {
    weather: weatherAgent,
    analytics: analyticsAgent,
    general: generalAgent,
  },
  tools: {
    getWeather: weatherTool,
    queryDatabase: databaseTool,
  },

  // Azure Monitor telemetry configuration
  telemetry: {
    serviceName: config.serviceName,
    enabled: config.environment !== 'test', // Disable in test environment
    
    // Sampling configuration based on environment
    sampling: {
      type: config.environment === 'production' ? 'ratio' : 'always_on',
      probability: config.environment === 'production' ? 0.1 : 1.0, // 10% in prod, 100% elsewhere
    },
    
    export: {
      type: 'azure-monitor',
      connectionString: config.connectionString,
      
      // Performance settings
      maxBatchSize: config.environment === 'production' ? 100 : 25,
      maxBatchIntervalMs: config.environment === 'production' ? 5000 : 2000,
      samplingPercentage: config.environment === 'production' ? 10 : 100,
      
      // Feature flags
      enableLiveMetrics: config.environment === 'production',
      enableAutoCollectExceptions: true,
      enableAutoCollectPerformance: true,
      enableAutoCollectDependencies: true,
      enableAutoCollectRequests: true,
      enableInternalDebugLogging: config.environment === 'development',
      enableInternalWarningLogging: true,
      
      // Application context
      environment: config.environment,
      version: config.version,
      cloudRole: config.serviceName,
      cloudRoleInstance: `${config.serviceName}-${config.clusterId}`,
      
      // Custom tags for rich filtering and grouping
      customTags: {
        // Technical metadata
        'app.name': config.serviceName,
        'app.version': config.version,
        'app.environment': config.environment,
        'infrastructure.region': config.region,
        'infrastructure.cluster': config.clusterId,
        'runtime.platform': 'nodejs',
        'runtime.version': process.version,
        
        // Business metadata
        'team': 'ai-platform',
        'cost-center': 'engineering',
        'product': 'mastra-demo',
        
        // Deployment metadata
        'deployment.type': process.env.DEPLOYMENT_TYPE || 'local',
        'build.commit': process.env.GIT_COMMIT || 'unknown',
        'build.branch': process.env.GIT_BRANCH || 'unknown',
        'build.timestamp': process.env.BUILD_TIMESTAMP || new Date().toISOString(),
      },
    },
  },
});
// Setup graceful shutdown to ensure telemetry is flushed
setupGracefulShutdown(mastra);

// Example usage functions that will generate telemetry
export async function handleWeatherRequest(location: string, userId?: string) {
  console.log(`Processing weather request for ${location}`);
  
  try {
    const agent = mastra.getAgent('weather');
    
    // This entire interaction will be traced, including:
    // - Agent execution span
    // - LLM API calls to OpenAI
    // - Tool execution (weather API call simulation)
    // - All with proper correlation IDs
    const response = await agent.generate([
      {
        role: 'user',
        content: `What's the weather like in ${location}? Please include temperature and conditions.`,
      },
    ]);

    console.log('Weather response generated successfully');
    return {
      success: true,
      response: response.text,
      location,
      userId,
    };
  } catch (error) {
    console.error('Error handling weather request:', error);
    
    // Error will be automatically tracked in Azure Monitor
    throw error;
  }
}

export async function handleAnalyticsRequest(userId: string, question: string) {
  console.log(`Processing analytics request for user ${userId}`);
  
  try {
    const agent = mastra.getAgent('analytics');
    
    // This will trace:
    // - Agent execution
    // - Claude API calls
    // - Database tool execution
    // - Custom properties and measurements
    const response = await agent.generate([
      {
        role: 'user', 
        content: `User ID: ${userId}. Question: ${question}`,
      },
    ]);

    console.log('Analytics response generated successfully');
    return {
      success: true,
      response: response.text,
      userId,
      question,
    };
  } catch (error) {
    console.error('Error handling analytics request:', error);
    throw error;
  }
}
export async function handleGeneralChat(message: string, conversationId?: string) {
  console.log(`Processing general chat message`);
  
  try {
    const agent = mastra.getAgent('general');
    
    // Simple agent interaction - will still be fully traced
    const response = await agent.generate([
      {
        role: 'user',
        content: message,
      },
    ]);

    console.log('General chat response generated successfully');
    return {
      success: true,
      response: response.text,
      conversationId,
    };
  } catch (error) {
    console.error('Error handling general chat:', error);
    throw error;
  }
}

// Health check endpoint
export async function healthCheck() {
  try {
    // Simple health check that will generate minimal telemetry
    const startTime = Date.now();
    
    // Test basic functionality
    const agent = mastra.getAgent('general');
    await agent.generate([
      {
        role: 'user',
        content: 'Health check - please respond with "OK"',
      },
    ]);
    
    const responseTime = Date.now() - startTime;
    
    return {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      responseTime,
      environment: config.environment,
      version: config.version,
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      environment: config.environment,
      version: config.version,
    };
  }
}
// Example usage in a CLI application
export async function runCLIExample() {
  console.log('Starting Mastra Azure Monitor Complete Example...');
  console.log(`Environment: ${config.environment}`);
  console.log(`Service: ${config.serviceName}`);
  console.log(`Version: ${config.version}`);
  
  try {
    // Example 1: Weather request
    console.log('\n--- Weather Request Example ---');
    const weatherResult = await handleWeatherRequest('New York, NY', 'user123');
    console.log('Weather Result:', weatherResult.success ? 'Success' : 'Failed');
    console.log('Response snippet:', weatherResult.response?.substring(0, 100) + '...');
    
    // Example 2: Analytics request  
    console.log('\n--- Analytics Request Example ---');
    const analyticsResult = await handleAnalyticsRequest('user123', 'What are my usage patterns?');
    console.log('Analytics Result:', analyticsResult.success ? 'Success' : 'Failed');
    console.log('Response snippet:', analyticsResult.response?.substring(0, 100) + '...');
    
    // Example 3: General chat
    console.log('\n--- General Chat Example ---');
    const chatResult = await handleGeneralChat('Hello! How are you today?', 'conv456');
    console.log('Chat Result:', chatResult.success ? 'Success' : 'Failed');
    console.log('Response snippet:', chatResult.response?.substring(0, 100) + '...');
    
    // Example 4: Health check
    console.log('\n--- Health Check Example ---');
    const health = await healthCheck();
    console.log('Health Check:', health.status, `(${health.responseTime}ms)`);
    
    console.log('\nAll examples completed successfully!');
    console.log('Check your Azure Monitor dashboard to see the telemetry data.');
    
  } catch (error) {
    console.error('Error running examples:', error);
    process.exit(1);
  }
}

// Export the configured Mastra instance
export { mastra, config };

// If this file is run directly, execute the CLI example
if (require.main === module) {
  runCLIExample().then(() => {
    console.log('CLI example completed');
    // Allow time for telemetry to flush
    setTimeout(() => process.exit(0), 3000);
  }).catch((error) => {
    console.error('CLI example failed:', error);
    process.exit(1);
  });
}