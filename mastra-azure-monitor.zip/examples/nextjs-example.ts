// nextjs-example.ts - Next.js integration example
import { createMastraWithAzureMonitor, setupGracefulShutdown } from '@local/azure-monitor';
import { Agent } from '@mastra/core/agent';
import { createTool } from '@mastra/core/tools';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// Example tool for a Next.js application
const userProfileTool = createTool({
  id: 'get-user-profile',
  description: 'Get user profile information',
  inputSchema: z.object({
    userId: z.string(),
  }),
  execute: async ({ context }) => {
    // Simulate database call that would happen in a Next.js API route
    console.log(`Fetching profile for user: ${context.userId}`);
    
    // Simulate API latency
    await new Promise(resolve => setTimeout(resolve, 150));
    
    return {
      userId: context.userId,
      name: `User ${context.userId}`,
      preferences: {
        theme: 'dark',
        language: 'en',
        timezone: 'UTC',
      },
      subscription: 'premium',
      lastLogin: new Date().toISOString(),
    };
  },
});

// Chat agent for Next.js application
const chatAgent = new Agent({
  name: 'chatAgent',
  instructions: `You are a helpful customer service assistant for a web application. 
    You can access user profile information to provide personalized assistance.
    Always be friendly and helpful.`,
  model: openai('gpt-4'),
  tools: [userProfileTool],
});

// Configure Mastra for Next.js deployment
const mastra = createMastraWithAzureMonitor({
  agents: {
    chat: chatAgent,
  },
  tools: {
    getUserProfile: userProfileTool,
  },
  telemetry: {
    serviceName: 'nextjs-chat-app',
    enabled: true,
    sampling: {
      type: 'parent_based', // Good for Next.js with multiple requests
      root: {
        probability: 0.3, // 30% sampling for root traces
      },
    },
    export: {
      type: 'azure-monitor',
      connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING || 'placeholder',
      
      // Next.js specific configuration
      enableLiveMetrics: process.env.NODE_ENV === 'production',
      cloudRole: 'web-frontend',
      cloudRoleInstance: `nextjs-${process.env.VERCEL_REGION || 'local'}`,
      
      // Web application context
      environment: process.env.NODE_ENV || 'development',
      version: process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0',
      
      customTags: {
        'framework': 'nextjs',
        'runtime': 'nodejs',
        'deployment.platform': process.env.VERCEL ? 'vercel' : 'local',
        'app.type': 'web-application',
      },
    },
  },
});

// Setup graceful shutdown (important for serverless environments)
setupGracefulShutdown(mastra);

// Simulate Next.js API route handler
export async function handleChatRequest(userId: string, message: string) {
  console.log(`Processing chat request from user ${userId}`);
  
  try {
    const agent = mastra.getAgent('chat');
    
    // This simulates what would happen in pages/api/chat.ts
    const response = await agent.generate([
      {
        role: 'user',
        content: `User ID: ${userId}. Message: ${message}`,
      },
    ]);

    return {
      success: true,
      response: response.text,
      userId,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error('Error in chat request:', error);
    
    return {
      success: false,
      error: 'Sorry, I encountered an error. Please try again.',
      userId,
      timestamp: new Date().toISOString(),
    };
  }
}

// Simulate Next.js middleware or API route
export async function handleUserProfileRequest(userId: string) {
  console.log(`Processing profile request for user ${userId}`);
  
  try {
    const tool = mastra.getTool('getUserProfile');
    
    if (!tool) {
      throw new Error('User profile tool not found');
    }
    
    const profile = await tool.execute({
      context: { userId },
    });

    return {
      success: true,
      data: profile,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error('Error fetching user profile:', error);
    
    return {
      success: false,
      error: 'Unable to fetch user profile',
      timestamp: new Date().toISOString(),
    };
  }
}

async function runNextjsExample() {
  console.log('🌐 Running Next.js Integration Example');
  console.log('This example shows how to use Azure Monitor in a Next.js application');
  console.log('');

  try {
    // Simulate multiple concurrent requests (like a real Next.js app)
    const requests = [
      handleChatRequest('user1', 'Hello! I need help with my account.'),
      handleChatRequest('user2', 'What features are available with my subscription?'),
      handleUserProfileRequest('user1'),
      handleUserProfileRequest('user2'),
      handleChatRequest('user3', 'How do I change my theme preferences?'),
    ];

    console.log('Processing 5 concurrent requests...');
    const results = await Promise.all(requests);

    console.log('Results:');
    results.forEach((result, index) => {
      console.log(`Request ${index + 1}:`, result.success ? '✅ Success' : '❌ Failed');
    });

    console.log('');
    console.log('✅ Next.js example completed successfully!');
    console.log('📊 All requests were traced with proper correlation in Azure Monitor');
    console.log('🔗 You can see the distributed traces in your Application Map');
    
  } catch (error) {
    console.error('❌ Error in Next.js example:', error);
    throw error;
  }
}

// Export for use in other files
export { mastra, runNextjsExample };

// Run if this file is executed directly
if (require.main === module) {
  runNextjsExample()
    .then(() => {
      console.log('Next.js example finished');
      setTimeout(() => process.exit(0), 2000);
    })
    .catch((error) => {
      console.error('Next.js example failed:', error);
      process.exit(1);
    });
}