# Mastra Azure Monitor - Local Package Implementation

A complete, production-ready Azure Monitor OpenTelemetry integration for Mastra applications using the **Local Package** approach. This implementation provides native integration between Mastra's observability system and Azure Monitor/Application Insights without requiring external npm packages.

## 🏗️ Architecture

This project demonstrates **Option 1: Local Package** approach where the Azure Monitor provider is implemented as a local package within your project:

```
mastra-azure-monitor/
├── lib/azure-monitor/          # Local Azure Monitor package
│   ├── src/
│   │   ├── azure-monitor-exporter.ts       # Core exporter implementation
│   │   ├── azure-monitor-provider.ts       # Provider configuration layer
│   │   ├── mastra-azure-monitor-integration.ts  # Mastra integration
│   │   └── index.ts                        # Main exports
│   ├── package.json                        # Package configuration
│   └── tsconfig.json                       # TypeScript configuration
├── src/                        # Main application code
│   ├── mastra.config.ts                    # Mastra configuration with Azure Monitor
│   └── app.ts                              # Example application
├── examples/
│   └── complete-example.ts                 # Comprehensive usage examples
├── package.json                            # Main project configuration
├── tsconfig.json                           # Main TypeScript configuration
└── README.md                               # This file
```

## 🚀 Features

### **Complete Azure Monitor Integration**
- ✅ **Native Azure Monitor API** - Direct integration with Azure Monitor APIs
- ✅ **Full Telemetry Support** - Traces, logs, metrics, and exceptions
- ✅ **Automatic Instrumentation** - Tracks agents, LLM calls, tools, and workflows
- ✅ **Production Ready** - Batching, error handling, graceful shutdown
- ✅ **Type Safety** - Full TypeScript support with proper types

### **Mastra-Specific Features**
- ✅ **Agent Tracing** - Complete agent conversation flows
- ✅ **LLM Call Monitoring** - Token usage, latency, model performance
- ✅ **Tool Execution Tracking** - Success rates, input/output parameters
- ✅ **Workflow Orchestration** - End-to-end workflow visibility
- ✅ **Custom Context** - Rich business and technical metadata

### **Local Package Benefits**
- ✅ **No External Dependencies** - Everything runs locally in your project
- ✅ **Full Customization** - Modify the code to fit your needs
- ✅ **Easy Development** - Simple to debug and extend
- ✅ **Version Control** - Track changes alongside your application code
- ✅ **Team Collaboration** - Share customizations across team members

## 📦 Quick Start

### **1. Clone or Copy**
```bash
# Copy this entire directory structure to your project
cp -r /path/to/this/directory /your/project/location
cd /your/project/location
```

### **2. Install Dependencies**
```bash
# Install main project dependencies
npm install

# Install Azure Monitor package dependencies
cd lib/azure-monitor
npm install
cd ../..
```

### **3. Environment Setup**
Create a `.env` file with your Azure Monitor connection string:

```env
# Required: Your Azure Monitor Application Insights connection string
APPLICATIONINSIGHTS_CONNECTION_STRING=InstrumentationKey=12345678-1234-1234-1234-123456789012;IngestionEndpoint=https://eastus-8.in.applicationinsights.azure.com/;LiveEndpoint=https://eastus.livediagnostics.monitor.azure.com/

# Optional: Additional configuration
NODE_ENV=development
APP_VERSION=1.0.0
SERVICE_NAME=my-mastra-app
```

### **4. Build & Run**
```bash
# Build the Azure Monitor package and main application
npm run build

# Run the example application
npm start

# For development with watch mode
npm run dev
```

## 💡 Usage Examples

### **Basic Configuration**
```typescript
import { createMastraWithAzureMonitor } from '@local/azure-monitor';

const mastra = createMastraWithAzureMonitor({
  telemetry: {
    serviceName: 'my-mastra-app',
    enabled: true,
    export: {
      type: 'azure-monitor',
      connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
    },
  },
});
```

### **Advanced Configuration**
```typescript
const mastra = createMastraWithAzureMonitor({
  agents: {
    // Your Mastra agents
  },
  tools: {
    // Your Mastra tools
  },
  telemetry: {
    serviceName: 'production-app',
    enabled: true,
    sampling: {
      type: 'ratio',
      probability: 0.8, // 80% sampling
    },
    export: {
      type: 'azure-monitor',
      connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
      enableLiveMetrics: true,
      enableAutoCollectExceptions: true,
      environment: process.env.NODE_ENV,
      version: process.env.APP_VERSION,
      cloudRole: 'mastra-service',
      customTags: {
        'team': 'ai-platform',
        'deployment': 'kubernetes',
      },
    },
  },
});
```

### **Environment-Based Configuration**
```typescript
import { environmentBasedExample } from '@local/azure-monitor';

// Automatically configures based on NODE_ENV
const mastra = environmentBasedExample();
```

## 🔧 Development Workflow

### **Daily Development**
```bash
# Start development mode (watches for changes)
npm run dev

# Build everything
npm run build

# Run the application
npm start

# Run specific examples
node dist/examples/complete-example.js
```

### **Modifying the Azure Monitor Package**
The Azure Monitor package is located in `lib/azure-monitor/`. You can:

1. **Customize the exporter** - Edit `azure-monitor-exporter.ts`
2. **Add new configuration options** - Update `azure-monitor-provider.ts`
3. **Extend Mastra integration** - Modify `mastra-azure-monitor-integration.ts`
4. **Add new exports** - Update `index.ts`

After making changes:
```bash
# Rebuild the Azure Monitor package
npm run build:azure-monitor

# Rebuild the main application
npm run build
```

## 📊 What Gets Tracked

### **🤖 Agent Operations**
- Agent initialization and configuration
- Multi-turn conversations with full context
- Agent tool usage and decision making
- Response generation time and success rates
- Custom agent metadata and properties

### **🧠 LLM Interactions** 
- Model API calls (OpenAI, Anthropic, etc.)
- Token usage, costs, and rate limiting
- Response latency and throughput metrics
- Error rates, retries, and timeout handling
- Model-specific performance characteristics

### **🔧 Tool Executions**
- Tool invocation traces with full parameters
- Input validation and output processing
- Execution duration and success/failure rates
- Tool-specific custom properties
- Error handling and retry logic

### **🔄 Workflow Orchestration**
- End-to-end workflow execution flows
- Step-by-step progress tracking
- Parallel and sequential processing patterns
- Resource utilization and performance
- Business logic and decision points

### **🔗 Integration Calls**
- External API calls and responses
- Database operations and queries
- File system operations
- Network requests and service dependencies
- Third-party service integrations

## 🎯 Azure Monitor Dashboard

Once running, you'll see rich telemetry in your Azure Monitor dashboard:

### **Application Map**
- **Service Topology** - Visual representation of your Mastra services
- **Dependency Relationships** - How agents, tools, and integrations interact  
- **Performance Bottlenecks** - Slow operations highlighted in red
- **Failure Rates** - Error patterns and problem areas
- **Traffic Flow** - Request volumes and patterns

### **Performance Insights**
- **Request Response Times** - Agent and workflow execution duration
- **LLM Call Performance** - Model API latency and success rates
- **Tool Execution Metrics** - Success rates and performance trends
- **Resource Utilization** - Memory, CPU, and network usage
- **Custom Metrics** - Business-specific KPIs and measurements

### **Rich Correlation**
- **Distributed Traces** - Complete request flows across all services
- **Correlation IDs** - Link related operations across components
- **Custom Properties** - Business context and technical metadata
- **Exception Tracking** - Detailed error information with stack traces
- **Log Correlation** - Connect logs to specific traces and spans

## 🔧 Configuration Reference

### **Telemetry Configuration**
```typescript
interface TelemetryConfig {
  serviceName?: string;          // Service identifier
  enabled?: boolean;             // Enable/disable telemetry
  sampling?: {
    type: 'ratio' | 'always_on' | 'always_off' | 'parent_based';
    probability?: number;         // 0.0 to 1.0 for ratio sampling
    root?: {
      probability: number;        // Root span sampling probability
    };
  };
  export: AzureMonitorExportConfig;
}
```

### **Azure Monitor Export Configuration**
```typescript
interface AzureMonitorExportConfig {
  type: 'azure-monitor';
  
  // Connection settings
  connectionString: string;       // Required: Azure Monitor connection string
  instrumentationKey?: string;    // Alternative (deprecated)
  endpointUrl?: string;          // Custom endpoint
  
  // Performance settings
  maxBatchSize?: number;         // Default: 100
  maxBatchIntervalMs?: number;   // Default: 5000
  samplingPercentage?: number;   // Default: 100
  
  // Feature flags
  enableLiveMetrics?: boolean;               // Default: false
  enableAutoCollectExceptions?: boolean;     // Default: true
  enableAutoCollectPerformance?: boolean;    // Default: true
  enableAutoCollectDependencies?: boolean;   // Default: true
  
  // Application context
  environment?: string;          // e.g., 'production', 'staging'
  version?: string;             // Application version
  cloudRole?: string;           // Service role name
  cloudRoleInstance?: string;   // Service instance identifier
  
  // Custom metadata
  customTags?: Record<string, string>;
}
```

## 🛠️ Customization Guide

### **Adding Custom Telemetry**
```typescript
// In your Azure Monitor exporter, you can add custom logic:

// 1. Custom span processing
private _spanToTelemetryItem(span: ReadableSpan): AzureMonitorTelemetryItem | null {
  // Add your custom logic here
  const customData = this._extractCustomData(span);
  
  // ... existing logic
}

// 2. Custom tags and properties
private _addCustomTags(span: ReadableSpan): { [key: string]: string } {
  return {
    'custom.business.unit': 'ai-platform',
    'custom.feature.flag': process.env.FEATURE_FLAG || 'disabled',
    // ... other custom tags
  };
}
```

### **Environment-Specific Configuration**
```typescript
// Create different configurations for different environments
const configs = {
  development: {
    sampling: { type: 'always_on' },
    enableInternalDebugLogging: true,
    maxBatchSize: 10,
  },
  staging: {
    sampling: { type: 'ratio', probability: 0.5 },
    enableLiveMetrics: false,
    maxBatchSize: 50,
  },
  production: {
    sampling: { type: 'ratio', probability: 0.1 },
    enableLiveMetrics: true,
    maxBatchSize: 100,
  },
};

const config = configs[process.env.NODE_ENV || 'development'];
```

## 📝 Project Scripts

```json
{
  "scripts": {
    "build": "npm run build:azure-monitor && tsc",
    "build:azure-monitor": "cd lib/azure-monitor && npm run build",
    "dev": "npm run build:azure-monitor && npm run dev:watch",
    "dev:watch": "concurrently \"cd lib/azure-monitor && npm run dev\" \"tsc --watch\"",
    "start": "npm run build && node dist/app.js",
    "example": "npm run build && node dist/examples/complete-example.js"
  }
}
```

## 🐛 Troubleshooting

### **Common Issues**

1. **Connection String Not Found**
   ```
   Error: Azure Monitor instrumentation key is required
   ```
   **Solution:** Set `APPLICATIONINSIGHTS_CONNECTION_STRING` environment variable

2. **TypeScript Path Resolution**
   ```
   Cannot find module '@local/azure-monitor'
   ```
   **Solution:** Check `tsconfig.json` paths configuration:
   ```json
   {
     "paths": {
       "@local/azure-monitor": ["./lib/azure-monitor/src/index"]
     }
   }
   ```

3. **Build Errors**
   ```
   Module not found: Can't resolve '@local/azure-monitor'
   ```
   **Solution:** Build the Azure Monitor package first:
   ```bash
   npm run build:azure-monitor
   ```

### **Debug Mode**
Enable debug logging to troubleshoot issues:
```typescript
export: {
  type: 'azure-monitor',
  connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
  enableInternalDebugLogging: true,
  enableInternalWarningLogging: true,
}
```

## 🔄 Migration to Published Package

When you're ready to convert this local package to a published npm package:

1. **Extract the package:**
   ```bash
   cp -r lib/azure-monitor ../mastra-azure-monitor-package
   cd ../mastra-azure-monitor-package
   ```

2. **Update package.json:**
   ```json
   {
     "name": "@your-org/mastra-azure-monitor",
     "version": "1.0.0",
     "publishConfig": {
       "registry": "https://registry.npmjs.org/"
     }
   }
   ```

3. **Publish:**
   ```bash
   npm publish --access public
   ```

4. **Update your project:**
   ```bash
   npm install @your-org/mastra-azure-monitor
   ```

## 📄 License

MIT License - feel free to customize and use this implementation in your projects.

## 🤝 Contributing

This is a local package implementation designed for customization. Feel free to:
- Modify the code to fit your specific needs
- Add new features and functionality
- Share improvements with your team
- Create your own published package based on this implementation

## 📞 Support

For questions about this implementation:
- Check the code comments for detailed explanations
- Review the examples for usage patterns
- Consult the Azure Monitor documentation for API details
- Modify the code to fit your specific requirements

---

**Happy coding!** 🚀