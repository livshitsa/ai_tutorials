# Quick Start Guide

Welcome to the Mastra Azure Monitor Local Package implementation! This guide will help you get up and running quickly.

## ⚡ 5-Minute Quick Start

### 1. **Automated Setup**
```bash
# Run the automated setup script
./setup.sh
```

This script will:
- ✅ Check prerequisites (Node.js 16+, npm)
- ✅ Install all dependencies
- ✅ Build the Azure Monitor package
- ✅ Build the main application
- ✅ Verify everything works

### 2. **Configure Azure Monitor**
```bash
# Edit the environment file
cp .env.example .env
```

Add your Azure Monitor connection string to `.env`:
```env
APPLICATIONINSIGHTS_CONNECTION_STRING=InstrumentationKey=your-key-here;IngestionEndpoint=https://your-region.in.applicationinsights.azure.com/
```

**Get your connection string from:** Azure Portal → Application Insights → Overview → Connection String

### 3. **Run Examples**
```bash
# Basic example
npm run example:basic

# Next.js integration example
npm run example:nextjs

# Production deployment example
npm run example:production

# Complete example with all features
npm run example:complete

# Main application
npm start
```

## 🛠️ Development Commands

```bash
# Development mode (watches for changes)
npm run dev

# Build everything
npm run build

# Build just the Azure Monitor package
npm run build:azure-monitor

# Run the main application
npm start

# Run specific examples
npm run example:basic
npm run example:nextjs
npm run example:production
npm run example:complete
```

## 📁 Project Structure

```
mastra-azure-monitor/
├── lib/azure-monitor/          # 📦 Local Azure Monitor package
│   ├── src/                    # TypeScript source files
│   ├── dist/                   # Compiled JavaScript (after build)
│   ├── package.json            # Package configuration
│   └── tsconfig.json           # TypeScript configuration
├── src/                        # 🚀 Main application
│   ├── mastra.config.ts        # Mastra configuration
│   └── app.ts                  # Example application
├── examples/                   # 📚 Usage examples
│   ├── basic-example.ts        # Simple usage
│   ├── nextjs-example.ts       # Next.js integration
│   ├── production-example.ts   # Production deployment
│   └── complete-example.ts     # All features demo
├── dist/                       # 🏗️ Compiled output (after build)
├── .env.example                # Environment variables template
├── setup.sh                    # Automated setup script
└── README.md                   # Complete documentation
```

## 🎯 What You Get

### **Automatic Telemetry Tracking**
- 🤖 **Agent Operations** - Complete conversation flows
- 🧠 **LLM API Calls** - Token usage, latency, costs
- 🔧 **Tool Executions** - Success rates, parameters
- 🔄 **Workflow Orchestration** - End-to-end visibility
- 🔗 **External Integrations** - API calls, database queries

### **Production Features**
- ✅ **Batching & Performance** - Efficient telemetry processing
- ✅ **Error Handling** - Robust retry logic and graceful degradation
- ✅ **Circuit Breaker** - Automatic failover for reliability
- ✅ **Health Monitoring** - Built-in health checks
- ✅ **Graceful Shutdown** - Ensures telemetry is flushed

### **Rich Azure Monitor Integration**
- 📊 **Application Map** - Service topology visualization
- 📈 **Performance Insights** - Request/response metrics
- 🔍 **Distributed Tracing** - Complete request flows
- 🚨 **Exception Tracking** - Detailed error information
- 📋 **Custom Properties** - Business context and metadata

## 🔧 Customization

### **Modify the Azure Monitor Package**
All Azure Monitor integration code is in `lib/azure-monitor/src/`:

```typescript
// lib/azure-monitor/src/azure-monitor-exporter.ts
// Core exporter implementation - modify telemetry format

// lib/azure-monitor/src/azure-monitor-provider.ts  
// Configuration and utilities - add new options

// lib/azure-monitor/src/mastra-azure-monitor-integration.ts
// Mastra integration layer - customize for your needs
```

After making changes:
```bash
npm run build:azure-monitor
npm run build
```

### **Environment-Specific Configuration**
```typescript
// Different configs for different environments
const configs = {
  development: {
    sampling: { type: 'always_on' },
    enableDebugLogging: true,
  },
  production: {
    sampling: { type: 'ratio', probability: 0.1 },
    enableLiveMetrics: true,
  },
};
```

### **Add Custom Tags**
```typescript
export: {
  type: 'azure-monitor',
  connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
  customTags: {
    'team': 'your-team',
    'product': 'your-product',
    'feature-flags': JSON.stringify(featureFlags),
  },
}
```

## 🎯 Next Steps

### **For Development**
1. Run `npm run dev` to start development mode
2. Modify files in `src/` or `lib/azure-monitor/src/`
3. Check Azure Monitor dashboard for telemetry

### **For Production**
1. Set production environment variables
2. Configure appropriate sampling rates
3. Enable Live Metrics
4. Set up monitoring alerts in Azure

### **For Team Sharing**
1. Commit the entire project to version control
2. Team members run `./setup.sh` to get started
3. Share environment variable templates

## 🆘 Need Help?

### **Common Issues**
- **Build Errors**: Run `npm run build:azure-monitor` first
- **Import Errors**: Check TypeScript path mapping in `tsconfig.json`
- **No Telemetry**: Verify connection string in `.env`

### **Debug Mode**
Enable debug logging to troubleshoot:
```env
ENABLE_DEBUG_LOGGING=true
```

### **Resources**
- 📖 **README.md** - Complete documentation
- 💡 **examples/** - Working code examples
- 🔧 **lib/azure-monitor/src/** - Source code with comments
- 🌐 **Azure Monitor Docs** - Official Azure documentation

---

**You're all set!** 🚀 Start with `npm run example:basic` to see it in action!