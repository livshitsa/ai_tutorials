// azure-monitor-provider.ts
import { AzureMonitorExporter, AzureMonitorExporterConfig } from './azure-monitor-exporter';

export interface AzureMonitorProviderConfig extends AzureMonitorExporterConfig {
  // Additional provider-specific options
  enableAutoInstrumentation?: boolean;
  enableConsoleLogging?: boolean;
  environment?: string;
  version?: string;
  cloudRole?: string;
  cloudRoleInstance?: string;
  userId?: string;
  sessionId?: string;
  customTags?: { [key: string]: string };
}

export class AzureMonitorProvider {
  private _exporter: AzureMonitorExporter;
  private _config: AzureMonitorProviderConfig;

  constructor(config: AzureMonitorProviderConfig) {
    this._config = config;
    this._exporter = new AzureMonitorExporter(config);
  }

  getExporter(): AzureMonitorExporter {
    return this._exporter;
  }

  getConfig(): AzureMonitorProviderConfig {
    return this._config;
  }

  async flush(): Promise<void> {
    await this._exporter.forceFlush();
  }

  async shutdown(): Promise<void> {
    await this._exporter.shutdown();
  }
}
// Factory function for easy integration with Mastra
export function createAzureMonitorProvider(config: AzureMonitorProviderConfig): AzureMonitorProvider {
  return new AzureMonitorProvider(config);
}

// Helper function to create exporter for direct Mastra integration
export function createAzureMonitorExporter(config: AzureMonitorExporterConfig): AzureMonitorExporter {
  return new AzureMonitorExporter(config);
}

// Type definitions for Mastra integration
export type MastraAzureMonitorConfig = {
  serviceName?: string;
  enabled?: boolean;
  sampling?: {
    type: 'ratio' | 'always_on' | 'always_off' | 'parent_based';
    probability?: number;
    root?: {
      probability: number;
    };
  };
  export: {
    type: 'azure-monitor';
    connectionString: string;
    instrumentationKey?: string;
    disableOfflineStorage?: boolean;
    enableLiveMetrics?: boolean;
    maxBatchSize?: number;
    maxBatchIntervalMs?: number;
    samplingPercentage?: number;
    environment?: string;
    version?: string;
    cloudRole?: string;
    cloudRoleInstance?: string;
    customTags?: { [key: string]: string };
  };
};

// Extended configuration options
export interface AzureMonitorConfigOptions {
  // Connection settings
  connectionString: string;
  instrumentationKey?: string;
  endpointUrl?: string;

  // Sampling and performance
  samplingPercentage?: number;
  maxBatchSize?: number;
  maxBatchIntervalMs?: number;
  disableOfflineStorage?: boolean;
  // Live metrics and monitoring
  enableLiveMetrics?: boolean;
  enableStatsD?: boolean;
  enableAutoCollectExceptions?: boolean;
  enableAutoCollectPerformance?: boolean;
  enableAutoCollectExtendedMetrics?: boolean;
  enableAutoCollectConsole?: boolean;
  enableAutoCollectDependencies?: boolean;
  enableAutoCollectRequests?: boolean;
  enableAutoCollectHeartbeat?: boolean;

  // Caching and retry
  enableUseDiskRetryCaching?: boolean;
  enableResendInterval?: number;
  enableMaxBytesOnDisk?: number;
  correlationIdRetryIntervalMs?: number;

  // Network and proxy
  correlationHeaderExcludedDomains?: string[];
  proxyHttpUrl?: string;
  proxyHttpsUrl?: string;
  httpAgent?: any;
  httpsAgent?: any;

  // Azure Functions specific
  enableAutoCollectIncomingRequestAzureFunctions?: boolean;
  enableAutoCollectDependencyAzureFunctions?: boolean;

  // Debugging and logging
  enableInternalDebugLogging?: boolean;
  enableInternalWarningLogging?: boolean;
  enableCollectExternalLoggers?: boolean;

  // Application context
  environment?: string;
  version?: string;
  cloudRole?: string;
  cloudRoleInstance?: string;
  userId?: string;
  sessionId?: string;
  customTags?: { [key: string]: string };

  // Advanced settings
  distributedTracingModes?: number;
  enableSendLiveMetrics?: boolean;
}
// Utility functions for configuration
export function parseConnectionString(connectionString: string): {
  instrumentationKey?: string;
  ingestionEndpoint?: string;
  liveEndpoint?: string;
} {
  const result: any = {};
  
  connectionString.split(';').forEach(part => {
    const [key, value] = part.split('=');
    if (key && value) {
      switch (key.toLowerCase()) {
        case 'instrumentationkey':
          result.instrumentationKey = value;
          break;
        case 'ingestionendpoint':
          result.ingestionEndpoint = value;
          break;
        case 'liveendpoint':
          result.liveEndpoint = value;
          break;
      }
    }
  });

  return result;
}

export function validateConfig(config: AzureMonitorProviderConfig): void {
  if (!config.connectionString && !config.instrumentationKey) {
    throw new Error('Azure Monitor configuration requires either connectionString or instrumentationKey');
  }

  if (config.samplingPercentage !== undefined && (config.samplingPercentage < 0 || config.samplingPercentage > 100)) {
    throw new Error('samplingPercentage must be between 0 and 100');
  }

  if (config.maxBatchSize !== undefined && config.maxBatchSize <= 0) {
    throw new Error('maxBatchSize must be greater than 0');
  }

  if (config.maxBatchIntervalMs !== undefined && config.maxBatchIntervalMs <= 0) {
    throw new Error('maxBatchIntervalMs must be greater than 0');
  }
}
// Error handling and retry logic
export class AzureMonitorError extends Error {
  constructor(
    message: string,
    public readonly code?: string,
    public readonly statusCode?: number,
    public readonly retryable: boolean = false
  ) {
    super(message);
    this.name = 'AzureMonitorError';
  }
}

export function isRetryableError(error: any): boolean {
  if (error instanceof AzureMonitorError) {
    return error.retryable;
  }

  // Network errors are generally retryable
  if (error.code === 'ECONNRESET' || error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
    return true;
  }

  // HTTP status codes that are retryable
  if (error.statusCode >= 500 || error.statusCode === 429 || error.statusCode === 408) {
    return true;
  }

  return false;
}

// Default configuration values
export const DEFAULT_CONFIG: Partial<AzureMonitorConfigOptions> = {
  samplingPercentage: 100,
  maxBatchSize: 100,
  maxBatchIntervalMs: 5000,
  disableOfflineStorage: false,
  enableLiveMetrics: false,
  enableStatsD: false,
  enableAutoCollectExceptions: true,
  enableAutoCollectPerformance: true,
  enableAutoCollectExtendedMetrics: false,
  enableAutoCollectConsole: true,
  enableAutoCollectDependencies: true,
  enableAutoCollectRequests: true,
  enableAutoCollectHeartbeat: true,
  enableUseDiskRetryCaching: true,
  enableResendInterval: 60000,
  enableMaxBytesOnDisk: 50 * 1024 * 1024, // 50MB
  correlationIdRetryIntervalMs: 30 * 1000,
  enableAutoCollectIncomingRequestAzureFunctions: false,
  enableAutoCollectDependencyAzureFunctions: false,
  enableInternalDebugLogging: false,
  enableInternalWarningLogging: true,
  enableCollectExternalLoggers: false,
  distributedTracingModes: 0,
  enableSendLiveMetrics: false,
  endpointUrl: 'https://dc.services.visualstudio.com',
};
// Helper to merge user config with defaults
export function mergeConfig(userConfig: AzureMonitorProviderConfig): AzureMonitorProviderConfig {
  return {
    ...DEFAULT_CONFIG,
    ...userConfig,
  };
}