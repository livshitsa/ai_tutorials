// index.ts - Main entry point for @local/azure-monitor package
export {
  AzureMonitorExporter,
  type AzureMonitorExporterConfig,
} from './azure-monitor-exporter';

export {
  AzureMonitorProvider,
  createAzureMonitorProvider,
  createAzureMonitorExporter,
  parseConnectionString,
  validateConfig,
  mergeConfig,
  AzureMonitorError,
  isRetryableError,
  DEFAULT_CONFIG,
  type AzureMonitorProviderConfig,
  type MastraAzureMonitorConfig,
  type AzureMonitorConfigOptions,
} from './azure-monitor-provider';

export {
  createMastraWithAzureMonitor,
  configureAzureMonitorForMastra,
  AzureMonitorHealthCheck,
  gracefulShutdown,
  setupGracefulShutdown,
  basicExample,
  advancedExample,
  environmentBasedExample,
  nextjsExample,
  microserviceExample,
  azureFunctionsExample,
  type MastraWithAzureMonitorConfig,
} from './mastra-azure-monitor-integration';

// Re-export commonly used types for convenience
export type {
  ExportResult,
  ExportResultCode,
} from '@opentelemetry/core';

export type {
  ReadableSpan,
  SpanExporter,
} from '@opentelemetry/sdk-trace-base';

export type {
  LogRecord,
  LogRecordExporter,
} from '@opentelemetry/sdk-logs';

export type {
  ResourceMetrics,
  MetricExporter,
} from '@opentelemetry/sdk-metrics';

// Version information
export const VERSION = '1.0.0';

// Default export for common use case
export default createMastraWithAzureMonitor;