// mastra-azure-monitor-integration.ts
import { Mastra } from '@mastra/core';
import { 
  createAzureMonitorExporter, 
  AzureMonitorProviderConfig,
  validateConfig,
  mergeConfig 
} from './azure-monitor-provider';

// Extended Mastra configuration to support Azure Monitor
export interface MastraWithAzureMonitorConfig {
  // Standard Mastra config
  agents?: any;
  tools?: any;
  workflows?: any;
  integrations?: any;
  
  // Azure Monitor telemetry configuration
  telemetry: {
    serviceName?: string;
    enabled?: boolean;
    sampling?: {
      type: 'ratio' | 'always_on' | 'always_off' | 'parent_based';
      probability?: number;
      root?: {
        probability: number;
      };
    };
    export: {
      type: 'azure-monitor';
      exporter?: any; // Will be the AzureMonitorExporter instance
    } & AzureMonitorProviderConfig;
  };
}

// Factory function to create Mastra instance with Azure Monitor
export function createMastraWithAzureMonitor(config: MastraWithAzureMonitorConfig): Mastra {
  if (config.telemetry.export.type !== 'azure-monitor') {
    throw new Error('Export type must be "azure-monitor" for Azure Monitor integration');
  }

  // Validate Azure Monitor configuration
  validateConfig(config.telemetry.export);

  // Merge with defaults
  const azureConfig = mergeConfig(config.telemetry.export);

  // Create the Azure Monitor exporter
  const azureMonitorExporter = createAzureMonitorExporter(azureConfig);
  // Create the Mastra configuration with the custom exporter
  const mastraConfig = {
    ...config,
    telemetry: {
      ...config.telemetry,
      export: {
        type: 'custom' as const,
        exporter: azureMonitorExporter,
      },
    },
  };

  return new Mastra(mastraConfig);
}

// Usage Examples

// 1. Basic Configuration
export const basicExample = () => {
  const mastra = createMastraWithAzureMonitor({
    telemetry: {
      serviceName: 'my-mastra-app',
      enabled: true,
      export: {
        type: 'azure-monitor',
        connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
      },
    },
  });

  return mastra;
};

// 2. Advanced Configuration
export const advancedExample = () => {
  const mastra = createMastraWithAzureMonitor({
    agents: {
      // Your agents here
    },
    tools: {
      // Your tools here  
    },
    telemetry: {
      serviceName: 'production-mastra-app',
      enabled: true,
      sampling: {
        type: 'ratio',
        probability: 0.8, // Sample 80% of traces
      },
      export: {
        type: 'azure-monitor',
        connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
        enableLiveMetrics: true,
        enableAutoCollectExceptions: true,
        enableAutoCollectPerformance: true,
        maxBatchSize: 50,
        maxBatchIntervalMs: 3000,
        samplingPercentage: 80,
        environment: process.env.NODE_ENV || 'development',
        version: process.env.APP_VERSION || '1.0.0',
        cloudRole: 'mastra-service',
        cloudRoleInstance: process.env.HOSTNAME || 'local',
        customTags: {
          'custom.deployment': 'kubernetes',
          'custom.region': 'us-east-1',
        },
      },
    },
  });

  return mastra;
};
// 3. Environment-based Configuration
export const environmentBasedExample = () => {
  const isDevelopment = process.env.NODE_ENV === 'development';
  const isProduction = process.env.NODE_ENV === 'production';

  const mastra = createMastraWithAzureMonitor({
    telemetry: {
      serviceName: `mastra-app-${process.env.NODE_ENV}`,
      enabled: !isDevelopment, // Disable in development
      sampling: {
        type: isProduction ? 'ratio' : 'always_on',
        probability: isProduction ? 0.1 : 1.0, // 10% in prod, 100% in other envs
      },
      export: {
        type: 'azure-monitor',
        connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
        enableLiveMetrics: isProduction,
        enableInternalDebugLogging: isDevelopment,
        enableInternalWarningLogging: true,
        environment: process.env.NODE_ENV,
        version: process.env.APP_VERSION,
        maxBatchSize: isProduction ? 100 : 10,
        maxBatchIntervalMs: isProduction ? 5000 : 1000,
      },
    },
  });

  return mastra;
};

// 4. Next.js Integration Example
export const nextjsExample = () => {
  // This would go in your mastra.config.ts
  const mastra = createMastraWithAzureMonitor({
    agents: {
      // Your agents
    },
    telemetry: {
      serviceName: 'nextjs-mastra-app',
      enabled: true,
      sampling: {
        type: 'parent_based',
        root: {
          probability: 0.5,
        },
      },
      export: {
        type: 'azure-monitor',
        connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
        enableLiveMetrics: true,
        cloudRole: 'web-frontend',
        customTags: {
          'framework': 'nextjs',
          'runtime': 'nodejs',
        },
      },
    },
  });

  return mastra;
};
// 5. Microservices Configuration
export const microserviceExample = (serviceName: string) => {
  const mastra = createMastraWithAzureMonitor({
    telemetry: {
      serviceName,
      enabled: true,
      sampling: {
        type: 'parent_based', // Respect parent sampling decisions
        root: {
          probability: 0.2, // 20% for root traces
        },
      },
      export: {
        type: 'azure-monitor',
        connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
        cloudRole: serviceName,
        cloudRoleInstance: `${serviceName}-${process.env.HOSTNAME || 'unknown'}`,
        enableAutoCollectDependencies: true,
        enableAutoCollectRequests: true,
        customTags: {
          'service.name': serviceName,
          'service.version': process.env.SERVICE_VERSION || '1.0.0',
          'deployment.environment': process.env.ENVIRONMENT || 'development',
        },
      },
    },
  });

  return mastra;
};

// 6. Azure Functions Integration
export const azureFunctionsExample = () => {
  const mastra = createMastraWithAzureMonitor({
    telemetry: {
      serviceName: 'azure-functions-mastra',
      enabled: true,
      sampling: {
        type: 'always_on', // Functions have short execution time
      },
      export: {
        type: 'azure-monitor',
        connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING!,
        enableAutoCollectIncomingRequestAzureFunctions: true,
        enableAutoCollectDependencyAzureFunctions: true,
        cloudRole: 'function-app',
        maxBatchSize: 25, // Smaller batches for Functions
        maxBatchIntervalMs: 2000, // Faster flush for short-lived Functions
        customTags: {
          'platform': 'azure-functions',
          'runtime': 'nodejs',
        },
      },
    },
  });

  return mastra;
};
// Utility functions for runtime configuration

export function configureAzureMonitorForMastra(options: {
  connectionString: string;
  serviceName?: string;
  environment?: string;
  samplingRate?: number;
  enableLiveMetrics?: boolean;
  customTags?: Record<string, string>;
}) {
  return {
    telemetry: {
      serviceName: options.serviceName || 'mastra-app',
      enabled: true,
      sampling: {
        type: 'ratio' as const,
        probability: options.samplingRate || 1.0,
      },
      export: {
        type: 'azure-monitor' as const,
        connectionString: options.connectionString,
        enableLiveMetrics: options.enableLiveMetrics || false,
        environment: options.environment,
        customTags: options.customTags,
      },
    },
  };
}

// Health check and monitoring utilities
export class AzureMonitorHealthCheck {
  private mastra: Mastra;
  private lastHealthCheck: Date | null = null;
  private isHealthy: boolean = true;

  constructor(mastra: Mastra) {
    this.mastra = mastra;
  }

  async checkHealth(): Promise<{ healthy: boolean; lastCheck: Date | null; message: string }> {
    try {
      // You could implement a health check by sending a test telemetry item
      // or checking the Azure Monitor endpoint
      this.isHealthy = true;
      this.lastHealthCheck = new Date();
      
      return {
        healthy: this.isHealthy,
        lastCheck: this.lastHealthCheck,
        message: 'Azure Monitor integration is healthy',
      };
    } catch (error) {
      this.isHealthy = false;
      return {
        healthy: false,
        lastCheck: this.lastHealthCheck,
        message: `Azure Monitor integration error: ${error}`,
      };
    }
  }

  getStatus() {
    return {
      healthy: this.isHealthy,
      lastCheck: this.lastHealthCheck,
    };
  }
}
// Graceful shutdown helper
export async function gracefulShutdown(mastra: Mastra): Promise<void> {
  try {
    // Force flush any pending telemetry
    const telemetryConfig = (mastra as any)._config?.telemetry;
    if (telemetryConfig?.export?.exporter?.forceFlush) {
      await telemetryConfig.export.exporter.forceFlush();
    }
    
    // Shutdown the exporter
    if (telemetryConfig?.export?.exporter?.shutdown) {
      await telemetryConfig.export.exporter.shutdown();
    }
    
    console.log('Azure Monitor telemetry gracefully shut down');
  } catch (error) {
    console.error('Error during graceful shutdown:', error);
  }
}

// Process signal handlers for graceful shutdown
export function setupGracefulShutdown(mastra: Mastra): void {
  const shutdown = () => {
    console.log('Received shutdown signal, flushing telemetry...');
    gracefulShutdown(mastra).then(() => {
      process.exit(0);
    }).catch((error) => {
      console.error('Error during shutdown:', error);
      process.exit(1);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
  process.on('SIGUSR2', shutdown); // For nodemon
}