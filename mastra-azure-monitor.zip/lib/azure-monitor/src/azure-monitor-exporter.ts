// azure-monitor-exporter.ts
import {
  ExportResult,
  ExportResultCode,
  hrTimeToMicroseconds,
} from '@opentelemetry/core';
import {
  ReadableSpan,
  SpanExporter,
} from '@opentelemetry/sdk-trace-base';
import {
  LogRecord,
  LogRecordExporter,
} from '@opentelemetry/sdk-logs';
import {
  ResourceMetrics,
  MetricExporter,
} from '@opentelemetry/sdk-metrics';

export interface AzureMonitorExporterConfig {
  connectionString: string;
  instrumentationKey?: string;
  disableOfflineStorage?: boolean;
  enableStatsD?: boolean;
  enableLiveMetrics?: boolean;
  enableAutoCollectExceptions?: boolean;
  enableAutoCollectPerformance?: boolean;
  enableAutoCollectExtendedMetrics?: boolean;
  enableAutoCollectConsole?: boolean;
  enableUseDiskRetryCaching?: boolean;
  enableResendInterval?: number;
  enableMaxBytesOnDisk?: number;
  samplingPercentage?: number;
  correlationIdRetryIntervalMs?: number;
  correlationHeaderExcludedDomains?: string[];
  proxyHttpUrl?: string;
  proxyHttpsUrl?: string;
  httpAgent?: any;
  httpsAgent?: any;
  enableAutoCollectDependencies?: boolean;
  enableAutoCollectRequests?: boolean;
  enableAutoCollectHeartbeat?: boolean;
  enableSendLiveMetrics?: boolean;
  enableCollectExternalLoggers?: boolean;
  distributedTracingModes?: number;
  enableAutoCollectIncomingRequestAzureFunctions?: boolean;
  enableAutoCollectDependencyAzureFunctions?: boolean;
  enableUseDiskRetryCaching?: boolean;
  enableInternalDebugLogging?: boolean;
  enableInternalWarningLogging?: boolean;
  endpointUrl?: string;
  maxBatchSize?: number;
  maxBatchIntervalMs?: number;
}
interface AzureMonitorTelemetryItem {
  ver: number;
  name: string;
  time: string;
  sampleRate: number;
  seq?: string;
  iKey: string;
  flags?: number;
  tags: { [key: string]: string };
  data: {
    baseType: string;
    baseData: any;
  };
}

interface RequestTelemetry {
  id: string;
  duration: string;
  responseCode: string;
  success: boolean;
  name: string;
  url: string;
  source?: string;
  properties?: { [key: string]: string };
  measurements?: { [key: string]: number };
}

interface DependencyTelemetry {
  id: string;
  name: string;
  data: string;
  duration: string;
  success: boolean;
  resultCode: string;
  type: string;
  target?: string;
  properties?: { [key: string]: string };
  measurements?: { [key: string]: number };
}
interface TraceTelemetry {
  message: string;
  severityLevel: number;
  properties?: { [key: string]: string };
  measurements?: { [key: string]: number };
}

interface ExceptionTelemetry {
  exceptions: Array<{
    typeName: string;
    message: string;
    hasFullStack: boolean;
    stack?: string;
    parsedStack?: any[];
  }>;
  severityLevel?: number;
  problemId?: string;
  properties?: { [key: string]: string };
  measurements?: { [key: string]: number };
}

interface MetricTelemetry {
  name: string;
  value: number;
  count?: number;
  min?: number;
  max?: number;
  stdDev?: number;
  properties?: { [key: string]: string };
}

export class AzureMonitorExporter implements SpanExporter, LogRecordExporter, MetricExporter {
  private readonly _config: AzureMonitorExporterConfig;
  private readonly _instrumentationKey: string;
  private readonly _endpointUrl: string;
  private readonly _maxBatchSize: number;
  private readonly _maxBatchIntervalMs: number;
  private _isShutdown = false;
  private _batchTimer?: NodeJS.Timeout;
  private _spanBuffer: ReadableSpan[] = [];
  private _logBuffer: LogRecord[] = [];

  constructor(config: AzureMonitorExporterConfig) {
    this._config = config;
    
    // Parse connection string to extract instrumentation key and endpoint
    const connectionStringParts = this._parseConnectionString(config.connectionString);
    this._instrumentationKey = connectionStringParts.instrumentationKey || config.instrumentationKey || '';
    this._endpointUrl = connectionStringParts.ingestionEndpoint || config.endpointUrl || 'https://dc.services.visualstudio.com';
    
    this._maxBatchSize = config.maxBatchSize || 100;
    this._maxBatchIntervalMs = config.maxBatchIntervalMs || 5000;

    if (!this._instrumentationKey) {
      throw new Error('Azure Monitor instrumentation key is required');
    }

    // Start batch timer
    this._startBatchTimer();
  }

  private _parseConnectionString(connectionString: string): {
    instrumentationKey?: string;
    ingestionEndpoint?: string;
    liveEndpoint?: string;
  } {
    const result: any = {};
    
    connectionString.split(';').forEach(part => {
      const [key, value] = part.split('=');
      if (key && value) {
        switch (key.toLowerCase()) {
          case 'instrumentationkey':
            result.instrumentationKey = value;
            break;
          case 'ingestionendpoint':
            result.ingestionEndpoint = value;
            break;
          case 'liveendpoint':
            result.liveEndpoint = value;
            break;
        }
      }
    });

    return result;
  }
  private _startBatchTimer(): void {
    this._batchTimer = setInterval(() => {
      this._flushBatches();
    }, this._maxBatchIntervalMs);
  }

  private async _flushBatches(): Promise<void> {
    if (this._spanBuffer.length > 0) {
      const spans = this._spanBuffer.splice(0, this._maxBatchSize);
      await this._exportSpanBatch(spans);
    }

    if (this._logBuffer.length > 0) {
      const logs = this._logBuffer.splice(0, this._maxBatchSize);
      await this._exportLogBatch(logs);
    }
  }

  // SpanExporter implementation
  export(spans: ReadableSpan[], resultCallback: (result: ExportResult) => void): void {
    if (this._isShutdown) {
      resultCallback({ code: ExportResultCode.FAILED });
      return;
    }

    // Add to buffer
    this._spanBuffer.push(...spans);

    // If buffer is full, flush immediately
    if (this._spanBuffer.length >= this._maxBatchSize) {
      this._flushBatches().then(() => {
        resultCallback({ code: ExportResultCode.SUCCESS });
      }).catch(() => {
        resultCallback({ code: ExportResultCode.FAILED });
      });
    } else {
      resultCallback({ code: ExportResultCode.SUCCESS });
    }
  }
  private async _exportSpanBatch(spans: ReadableSpan[]): Promise<void> {
    const telemetryItems: AzureMonitorTelemetryItem[] = [];

    for (const span of spans) {
      const telemetryItem = this._spanToTelemetryItem(span);
      if (telemetryItem) {
        telemetryItems.push(telemetryItem);
      }
    }

    if (telemetryItems.length > 0) {
      await this._sendTelemetryItems(telemetryItems);
    }
  }

  private _spanToTelemetryItem(span: ReadableSpan): AzureMonitorTelemetryItem | null {
    const startTime = new Date(hrTimeToMicroseconds(span.startTime) / 1000);
    const duration = hrTimeToMicroseconds(span.duration) / 1000; // Convert to milliseconds

    // Determine telemetry type based on span kind and attributes
    const spanKind = span.kind;
    const attributes = span.attributes;
    const spanName = span.name;

    // Common tags
    const tags: { [key: string]: string } = {
      'ai.operation.id': span.spanContext().traceId,
      'ai.operation.parentId': span.parentSpanId || '',
      'ai.operation.name': spanName,
      'ai.internal.sdkVersion': 'mastra-azure-monitor-exporter:1.0.0',
    };

    // Add resource attributes as tags
    Object.entries(span.resource.attributes).forEach(([key, value]) => {
      if (typeof value === 'string') {
        tags[`ai.cloud.${key}`] = value;
      }
    });

    let baseType: string;
    let baseData: any;

    // Determine if this is a request, dependency, or trace
    if (spanKind === 1 || spanKind === 2) { // SERVER or CONSUMER
      // This is an incoming request
      baseType = 'RequestData';
      baseData = this._createRequestTelemetry(span, duration);
    } else if (spanKind === 3 || spanKind === 4) { // CLIENT or PRODUCER  
      // This is an outgoing dependency
      baseType = 'RemoteDependencyData';
      baseData = this._createDependencyTelemetry(span, duration);
    } else {
      // Internal span - create as trace
      baseType = 'MessageData';
      baseData = this._createTraceTelemetry(span);
    }

    return {
      ver: 1,
      name: `Microsoft.ApplicationInsights.${baseType.replace('Data', '')}`,
      time: startTime.toISOString(),
      sampleRate: 100,
      iKey: this._instrumentationKey,
      tags,
      data: {
        baseType,
        baseData,
      },
    };
  }

  private _createRequestTelemetry(span: ReadableSpan, duration: number): RequestTelemetry {
    const attributes = span.attributes;
    const httpMethod = attributes['http.method'] as string || 'GET';
    const httpUrl = attributes['http.url'] as string || attributes['url.full'] as string || '';
    const httpStatusCode = attributes['http.status_code'] as number || attributes['http.response.status_code'] as number || 200;
    
    return {
      id: span.spanContext().spanId,
      duration: this._formatDuration(duration),
      responseCode: httpStatusCode.toString(),
      success: httpStatusCode < 400,
      name: `${httpMethod} ${span.name}`,
      url: httpUrl,
      properties: this._extractProperties(attributes),
      measurements: this._extractMeasurements(attributes),
    };
  }
  private _createDependencyTelemetry(span: ReadableSpan, duration: number): DependencyTelemetry {
    const attributes = span.attributes;
    const httpMethod = attributes['http.method'] as string || '';
    const httpUrl = attributes['http.url'] as string || attributes['url.full'] as string || '';
    const httpStatusCode = attributes['http.status_code'] as number || attributes['http.response.status_code'] as number || 200;
    const dbSystem = attributes['db.system'] as string;
    const rpcService = attributes['rpc.service'] as string;

    let dependencyType = 'HTTP';
    let target = '';
    let data = httpUrl;

    if (dbSystem) {
      dependencyType = dbSystem;
      target = attributes['db.connection_string'] as string || attributes['server.address'] as string || '';
      data = attributes['db.statement'] as string || span.name;
    } else if (rpcService) {
      dependencyType = 'RPC';
      target = rpcService;
      data = span.name;
    } else if (httpUrl) {
      try {
        const url = new URL(httpUrl);
        target = url.hostname;
      } catch {
        target = httpUrl;
      }
    }

    return {
      id: span.spanContext().spanId,
      name: span.name,
      data: data,
      duration: this._formatDuration(duration),
      success: !span.status || span.status.code !== 2, // ERROR = 2
      resultCode: httpStatusCode ? httpStatusCode.toString() : '0',
      type: dependencyType,
      target,
      properties: this._extractProperties(attributes),
      measurements: this._extractMeasurements(attributes),
    };
  }
  private _createTraceTelemetry(span: ReadableSpan): TraceTelemetry {
    const attributes = span.attributes;
    let severityLevel = 1; // Information

    if (span.status && span.status.code === 2) { // ERROR
      severityLevel = 3; // Error
    }

    return {
      message: span.name,
      severityLevel,
      properties: this._extractProperties(attributes),
      measurements: this._extractMeasurements(attributes),
    };
  }

  private _extractProperties(attributes: any): { [key: string]: string } {
    const properties: { [key: string]: string } = {};
    
    Object.entries(attributes).forEach(([key, value]) => {
      if (typeof value === 'string' || typeof value === 'boolean') {
        properties[key] = value.toString();
      }
    });

    return properties;
  }

  private _extractMeasurements(attributes: any): { [key: string]: number } {
    const measurements: { [key: string]: number } = {};
    
    Object.entries(attributes).forEach(([key, value]) => {
      if (typeof value === 'number') {
        measurements[key] = value;
      }
    });

    return measurements;
  }
  private _formatDuration(durationMs: number): string {
    // Convert to .NET TimeSpan format (HH:mm:ss.fffffff)
    const totalSeconds = Math.floor(durationMs / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const milliseconds = Math.floor(durationMs % 1000);
    const ticks = (durationMs % 1) * 10000; // Convert fractional part to ticks

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${milliseconds.toString().padStart(3, '0')}${Math.floor(ticks).toString().padStart(4, '0')}`;
  }

  // LogRecordExporter implementation
  export(logs: LogRecord[], resultCallback: (result: ExportResult) => void): void {
    if (this._isShutdown) {
      resultCallback({ code: ExportResultCode.FAILED });
      return;
    }

    this._logBuffer.push(...logs);

    if (this._logBuffer.length >= this._maxBatchSize) {
      this._flushBatches().then(() => {
        resultCallback({ code: ExportResultCode.SUCCESS });
      }).catch(() => {
        resultCallback({ code: ExportResultCode.FAILED });
      });
    } else {
      resultCallback({ code: ExportResultCode.SUCCESS });
    }
  }

  private async _exportLogBatch(logs: LogRecord[]): Promise<void> {
    const telemetryItems: AzureMonitorTelemetryItem[] = [];

    for (const log of logs) {
      const telemetryItem = this._logToTelemetryItem(log);
      if (telemetryItem) {
        telemetryItems.push(telemetryItem);
      }
    }

    if (telemetryItems.length > 0) {
      await this._sendTelemetryItems(telemetryItems);
    }
  }
  private _logToTelemetryItem(log: LogRecord): AzureMonitorTelemetryItem | null {
    const timestamp = new Date(hrTimeToMicroseconds(log.hrTime) / 1000);
    
    const tags: { [key: string]: string } = {
      'ai.operation.id': log.spanContext?.traceId || '',
      'ai.operation.parentId': log.spanContext?.spanId || '',
      'ai.internal.sdkVersion': 'mastra-azure-monitor-exporter:1.0.0',
    };

    let severityLevel = 1; // Information
    if (log.severityNumber) {
      if (log.severityNumber >= 17) severityLevel = 4; // Critical
      else if (log.severityNumber >= 13) severityLevel = 3; // Error  
      else if (log.severityNumber >= 9) severityLevel = 2; // Warning
      else severityLevel = 1; // Information
    }

    const baseData: TraceTelemetry = {
      message: log.body?.toString() || '',
      severityLevel,
      properties: this._extractProperties(log.attributes || {}),
    };

    return {
      ver: 1,
      name: 'Microsoft.ApplicationInsights.Message',
      time: timestamp.toISOString(),
      sampleRate: 100,
      iKey: this._instrumentationKey,
      tags,
      data: {
        baseType: 'MessageData',
        baseData,
      },
    };
  }

  // MetricExporter implementation  
  export(metrics: ResourceMetrics, resultCallback: (result: ExportResult) => void): void {
    if (this._isShutdown) {
      resultCallback({ code: ExportResultCode.FAILED });
      return;
    }

    this._exportMetrics(metrics).then(() => {
      resultCallback({ code: ExportResultCode.SUCCESS });
    }).catch(() => {
      resultCallback({ code: ExportResultCode.FAILED });
    });
  }
  private async _exportMetrics(resourceMetrics: ResourceMetrics): Promise<void> {
    const telemetryItems: AzureMonitorTelemetryItem[] = [];

    for (const scopeMetrics of resourceMetrics.scopeMetrics) {
      for (const metric of scopeMetrics.metrics) {
        for (const dataPoint of metric.dataPoints) {
          const telemetryItem = this._metricToTelemetryItem(metric, dataPoint, resourceMetrics.resource);
          if (telemetryItem) {
            telemetryItems.push(telemetryItem);
          }
        }
      }
    }

    if (telemetryItems.length > 0) {
      await this._sendTelemetryItems(telemetryItems);
    }
  }

  private _metricToTelemetryItem(metric: any, dataPoint: any, resource: any): AzureMonitorTelemetryItem | null {
    const timestamp = new Date(hrTimeToMicroseconds(dataPoint.startTime) / 1000);
    
    const tags: { [key: string]: string } = {
      'ai.internal.sdkVersion': 'mastra-azure-monitor-exporter:1.0.0',
    };

    let value: number;
    let count: number | undefined;
    let min: number | undefined;
    let max: number | undefined;
    let stdDev: number | undefined;

    // Handle different metric types
    if (dataPoint.value !== undefined) {
      value = dataPoint.value;
    } else if (dataPoint.sum !== undefined) {
      value = dataPoint.sum;
      count = dataPoint.count;
      min = dataPoint.min;
      max = dataPoint.max;
    } else {
      return null;
    }
    const baseData: MetricTelemetry = {
      name: metric.descriptor.name,
      value,
      count,
      min,
      max,
      stdDev,
      properties: this._extractProperties(dataPoint.attributes || {}),
    };

    return {
      ver: 1,
      name: 'Microsoft.ApplicationInsights.Metric',
      time: timestamp.toISOString(),
      sampleRate: 100,
      iKey: this._instrumentationKey,
      tags,
      data: {
        baseType: 'MetricData',
        baseData,
      },
    };
  }

  private async _sendTelemetryItems(items: AzureMonitorTelemetryItem[]): Promise<void> {
    const url = `${this._endpointUrl}/v2/track`;
    
    const payload = JSON.stringify(items);
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload, 'utf8').toString(),
        },
        body: payload,
      });

      if (!response.ok) {
        console.error('Failed to send telemetry to Azure Monitor:', response.status, await response.text());
      }
    } catch (error) {
      console.error('Error sending telemetry to Azure Monitor:', error);
    }
  }

  async forceFlush(): Promise<void> {
    await this._flushBatches();
  }

  async shutdown(): Promise<void> {
    this._isShutdown = true;
    
    if (this._batchTimer) {
      clearInterval(this._batchTimer);
    }

    await this._flushBatches();
  }
}