// app.ts
import { mastra } from './mastra.config';
import { setupGracefulShutdown } from '@local/azure-monitor';

// Setup graceful shutdown to ensure telemetry is flushed
setupGracefulShutdown(mastra);

async function main() {
  console.log('🚀 Starting Mastra Azure Monitor Local Package Example...');
  console.log('Environment:', process.env.NODE_ENV || 'development');
  console.log('Azure Monitor configured:', !!process.env.APPLICATIONINSIGHTS_CONNECTION_STRING);
  console.log('');

  try {
    // Example 1: Weather agent interaction
    console.log('--- Weather Agent Example ---');
    const weatherAgent = mastra.getAgent('weather');
    
    const weatherResponse = await weatherAgent.generate([
      {
        role: 'user',
        content: 'What is the weather like in New York?',
      },
    ]);
    
    console.log('Weather Response:', weatherResponse.text);
    console.log('');

    // Example 2: General agent interaction
    console.log('--- General Agent Example ---');
    const generalAgent = mastra.getAgent('general');
    
    const generalResponse = await generalAgent.generate([
      {
        role: 'user',
        content: 'Hello! Tell me a fun fact about TypeScript.',
      },
    ]);
    
    console.log('General Response:', generalResponse.text);
    console.log('');

    // Example 3: Direct tool usage
    console.log('--- Direct Tool Usage Example ---');
    const weatherTool = mastra.getTool('getWeather');
    
    if (weatherTool) {
      const toolResult = await weatherTool.execute({
        context: {
          location: 'San Francisco, CA',
          units: 'fahrenheit' as const,
        },
      });
      
      console.log('Tool Result:', JSON.stringify(toolResult, null, 2));
    }
    
    console.log('');
    console.log('✅ All examples completed successfully!');
    console.log('📊 Check your Azure Monitor dashboard to see the telemetry data.');
    console.log('🔗 https://portal.azure.com > Application Insights > your resource');
    
  } catch (error) {
    console.error('❌ Error running examples:', error);
    process.exit(1);
  }
}

// Run the main function
if (require.main === module) {
  main().then(() => {
    console.log('');
    console.log('Example completed successfully!');
    // Don't exit immediately to allow telemetry to flush
    setTimeout(() => {
      process.exit(0);
    }, 2000);
  }).catch((error) => {
    console.error('Example failed:', error);
    process.exit(1);
  });
}