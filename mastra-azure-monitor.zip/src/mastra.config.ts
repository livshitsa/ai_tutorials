// mastra.config.ts
import { createMastraWithAzureMonitor } from '@local/azure-monitor';
import { Agent } from '@mastra/core/agent';
import { createTool } from '@mastra/core/tools';
import { openai } from '@ai-sdk/openai';
import { anthropic } from '@ai-sdk/anthropic';
import { z } from 'zod';

// Example tool
const weatherTool = createTool({
  id: 'get-weather',
  description: 'Get current weather for a location',
  inputSchema: z.object({
    location: z.string().describe('The city and country'),
    units: z.enum(['celsius', 'fahrenheit']).default('celsius'),
  }),
  execute: async ({ context }) => {
    // Simulate a weather API call - this will be traced automatically
    console.log(`Getting weather for ${context.location}`);
    await new Promise(resolve => setTimeout(resolve, 200)); // Simulate latency
    
    return {
      location: context.location,
      temperature: 22,
      description: 'Partly cloudy',
      humidity: 65,
      units: context.units,
    };
  },
});

// Example agents
const weatherAgent = new Agent({
  name: 'weatherAgent',
  instructions: 'You are a weather assistant. Use the weather tool to get current conditions.',
  model: openai('gpt-4'),
  tools: [weatherTool],
});

const generalAgent = new Agent({
  name: 'generalAgent',
  instructions: 'You are a helpful general-purpose assistant.',
  model: anthropic('claude-3-haiku-20240307'),
});

// Configure Mastra with Azure Monitor
export const mastra = createMastraWithAzureMonitor({
  agents: {
    weather: weatherAgent,
    general: generalAgent,
  },
  tools: {
    getWeather: weatherTool,
  },
  telemetry: {
    serviceName: 'mastra-azure-monitor-local',
    enabled: true,
    sampling: {
      type: 'ratio',
      probability: 1.0, // 100% sampling for local development
    },
    export: {
      type: 'azure-monitor',
      connectionString: process.env.APPLICATIONINSIGHTS_CONNECTION_STRING || 'InstrumentationKey=placeholder;IngestionEndpoint=https://dc.services.visualstudio.com/',
      enableLiveMetrics: false, // Disable for local development
      enableInternalDebugLogging: true,
      enableInternalWarningLogging: true,
      environment: process.env.NODE_ENV || 'development',
      version: '1.0.0',
      cloudRole: 'local-development',
      cloudRoleInstance: 'localhost',
      customTags: {
        'deployment.type': 'local',
        'package.type': 'local-package',
        'developer': process.env.USER || 'unknown',
      },
    },
  },
});