#!/bin/bash

# setup.sh - Automated setup script for Mastra Azure Monitor Local Package

set -e

echo "🚀 Mastra Azure Monitor Local Package Setup"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# Check prerequisites
check_prerequisites() {
    print_info "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed. Please install Node.js 16+ first."
        exit 1
    fi
    
    # Check Node.js version
    NODE_VERSION=$(node --version | cut -d 'v' -f 2 | cut -d '.' -f 1)
    if [ "$NODE_VERSION" -lt 16 ]; then
        print_error "Node.js version 16+ is required. Current version: $(node --version)"
        exit 1
    fi
    
    # Check npm
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    print_success "Prerequisites check passed"
}

# Setup environment file
setup_environment() {
    print_info "Setting up environment file..."
    
    if [ ! -f ".env" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env
            print_success "Created .env file from .env.example"
            print_warning "Please edit .env file and add your Azure Monitor connection string"
        else
            print_error ".env.example file not found"
            exit 1
        fi
    else
        print_warning ".env file already exists, skipping creation"
    fi
}

# Install dependencies
install_dependencies() {
    print_info "Installing main project dependencies..."
    
    if [ -f "package.json" ]; then
        npm install
        print_success "Main project dependencies installed"
    else
        print_error "package.json not found in current directory"
        exit 1
    fi
    
    print_info "Installing Azure Monitor package dependencies..."
    
    if [ -d "lib/azure-monitor" ]; then
        cd lib/azure-monitor
        if [ -f "package.json" ]; then
            npm install
            print_success "Azure Monitor package dependencies installed"
        else
            print_error "lib/azure-monitor/package.json not found"
            exit 1
        fi
        cd ../..
    else
        print_error "lib/azure-monitor directory not found"
        exit 1
    fi
}

# Build the project
build_project() {
    print_info "Building the project..."
    
    # Build Azure Monitor package first
    print_info "Building Azure Monitor package..."
    cd lib/azure-monitor
    npm run build
    cd ../..
    print_success "Azure Monitor package built successfully"
    
    # Build main project
    print_info "Building main project..."
    npm run build
    print_success "Main project built successfully"
}

# Verify setup
verify_setup() {
    print_info "Verifying setup..."
    
    # Check if dist directories exist
    if [ -d "lib/azure-monitor/dist" ]; then
        print_success "Azure Monitor package build output found"
    else
        print_error "Azure Monitor package build failed - dist directory not found"
        exit 1
    fi
    
    if [ -d "dist" ]; then
        print_success "Main project build output found"
    else
        print_error "Main project build failed - dist directory not found"
        exit 1
    fi
    
    # Check key files
    if [ -f "lib/azure-monitor/dist/index.js" ]; then
        print_success "Azure Monitor package entry point found"
    else
        print_error "Azure Monitor package entry point not found"
        exit 1
    fi
    
    if [ -f "dist/app.js" ]; then
        print_success "Main application entry point found"
    else
        print_error "Main application entry point not found"
        exit 1
    fi
}

# Test the setup
test_setup() {
    print_info "Testing the setup..."
    
    # Check if .env has been configured
    if grep -q "InstrumentationKey=12345678" .env 2>/dev/null; then
        print_warning "Please update your .env file with a real Azure Monitor connection string"
        print_info "The application will run but telemetry may not be sent to Azure Monitor"
    fi
    
    print_info "Running a quick test..."
    
    # Try to import the Azure Monitor package
    node -e "
        try {
            const { createMastraWithAzureMonitor } = require('./lib/azure-monitor/dist/index.js');
            console.log('✅ Azure Monitor package import successful');
        } catch (error) {
            console.error('❌ Azure Monitor package import failed:', error.message);
            process.exit(1);
        }
    "
    
    print_success "Setup test passed"
}

# Main setup function
main() {
    echo "Starting automated setup..."
    echo ""
    
    check_prerequisites
    echo ""
    
    setup_environment
    echo ""
    
    install_dependencies
    echo ""
    
    build_project
    echo ""
    
    verify_setup
    echo ""
    
    test_setup
    echo ""
    
    print_success "Setup completed successfully!"
    echo ""
    echo "🎉 Your Mastra Azure Monitor Local Package is ready!"
    echo ""
    echo "Next steps:"
    echo "1. Edit .env file and add your Azure Monitor connection string"
    echo "2. Run 'npm start' to test the application"
    echo "3. Run 'npm run dev' for development mode"
    echo "4. Check the examples/ directory for more usage patterns"
    echo ""
    echo "Useful commands:"
    echo "  npm start                 - Run the main application"
    echo "  npm run dev              - Start development mode with watch"
    echo "  npm run build            - Build everything"
    echo "  npm run build:azure-monitor - Build just the Azure Monitor package"
    echo ""
    echo "Documentation:"
    echo "  README.md                - Complete documentation"
    echo "  .env.example            - Environment variables reference"
    echo "  examples/               - Usage examples"
    echo ""
    print_info "Happy coding! 🚀"
}

# Run main function
main "$@"